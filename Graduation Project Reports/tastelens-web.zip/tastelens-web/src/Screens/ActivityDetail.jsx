import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import activities from "../data/Activities";
import {
  FaStar,
  FaMapMarkerAlt,
  FaClock,
  FaTag,
  FaCheck,
  FaArrowLeft,
  FaMap,
} from "react-icons/fa";

const locationCoordinates = {
  Amman: { lat: 31.9497, lng: 35.9327, color: "bg-purple-500" },
  Aqaba: { lat: 29.5319, lng: 35.0061, color: "bg-blue-500" },
  Petra: { lat: 30.3285, lng: 35.4444, color: "bg-red-500" },
  "Dead Sea": { lat: 31.559, lng: 35.4732, color: "bg-green-500" },
  Jerash: { lat: 32.2749, lng: 35.8969, color: "bg-yellow-500" },
  Madaba: { lat: 31.7195, lng: 35.7932, color: "bg-pink-500" },
  Ajloun: { lat: 32.3325, lng: 35.7519, color: "bg-indigo-500" },
  "Wadi Rum": { lat: 29.5833, lng: 35.4167, color: "bg-orange-500" },
  Dana: { lat: 30.6833, lng: 35.5833, color: "bg-teal-500" },
};

const ActivityDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showPopup, setShowPopup] = useState(false);

  const activity = activities.find((a) => a.id === parseInt(id));

  if (!activity) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-bold text-gray-800 mb-4">
            Activity not found
          </h2>
          <button
            onClick={() => navigate("/activities")}
            className="px-6 py-3 bg-purple-600 text-white rounded-lg"
          >
            Back to Activities
          </button>
        </div>
      </div>
    );
  }

  const city = activity.location.split(",")[0];
  const coordinates = locationCoordinates[city] || locationCoordinates["Amman"];

  const handleBookNow = () => setShowPopup(true);
  const handleClosePopup = () => setShowPopup(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Navigation */}
        <div className="mb-6">
          <button
            onClick={() => navigate("/activities")}
            className="flex items-center text-purple-600 hover:text-purple-800 font-medium"
          >
            <FaArrowLeft className="mr-2" />
            Back to Activities
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Hero Image */}
          <div className="relative h-64 md:h-80 overflow-hidden">
            <img
              src={activity.image}
              alt={activity.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
            <div className="absolute bottom-6 left-6 text-white">
              <span className="bg-white/20 backdrop-blur-sm px-4 py-1.5 rounded-full text-sm font-medium">
                {activity.category}
              </span>
            </div>
            <div className="absolute top-6 right-6">
              <div className="bg-white/90 backdrop-blur-sm px-4 py-2 rounded-xl">
                <div className="text-2xl font-bold text-gray-900">
                  {activity.price_range}
                </div>
              </div>
            </div>
          </div>

          {/* Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-6 md:p-8">
            {/* Left Column - Main Info */}
            <div className="lg:col-span-2 space-y-8">
              {/* Header */}
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-3">
                  {activity.name}
                </h1>
                <div className="flex items-center gap-6 text-gray-600 mb-4">
                  <span className="flex items-center">
                    <FaMapMarkerAlt className="mr-2" />
                    {activity.location}
                  </span>
                  <span className="flex items-center">
                    <FaClock className="mr-2" />
                    {activity.duration}
                  </span>
                </div>
                <div className="flex items-center">
                  <div className="flex items-center text-amber-500">
                    <FaStar />
                    <FaStar />
                    <FaStar />
                    <FaStar />
                    <FaStar className="text-amber-300" />
                  </div>
                  <span className="ml-2 font-bold text-gray-900">
                    {activity.rating}
                  </span>
                  <span className="mx-2 text-gray-400">•</span>
                  <span className="text-gray-600">
                    {activity.difficulty} Level
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="prose max-w-none">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  About this experience
                </h2>
                <p className="text-gray-700 leading-relaxed">
                  {activity.description}
                </p>
              </div>

              {/* Included Features */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                  <FaCheck className="mr-2 text-green-600" />
                  What's included
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {activity.included.map((item, index) => (
                    <div
                      key={index}
                      className="flex items-center bg-gray-50 p-3 rounded-lg"
                    >
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-gray-700">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tags */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                  <FaTag className="mr-2" />
                  Tags
                </h2>
                <div className="flex flex-wrap gap-2">
                  {activity.tags.map((tag) => (
                    <span
                      key={tag}
                      className="bg-purple-100 text-purple-700 px-4 py-2 rounded-full hover:bg-purple-200 transition-colors"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Map & Booking */}
            <div className="space-y-6">
              {/* Map Card */}
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-6 border border-gray-200">
                <div className="flex items-center mb-4">
                  <FaMap className="mr-3 text-purple-600" />
                  <h3 className="text-lg font-semibold text-gray-900">
                    Location Map
                  </h3>
                </div>
                <div className="relative bg-blue-50 rounded-lg overflow-hidden border border-blue-200 h-64">
                  {/* Jordan Shape */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-48 h-32 bg-gradient-to-r from-green-100 to-green-50 border-2 border-green-300 rounded-lg">
                      <div
                        className={`absolute w-6 h-6 ${coordinates.color} rounded-full border-2 border-white shadow-lg animate-pulse`}
                        style={{
                          left: `${coordinates.lng - 34}%`,
                          top: `${coordinates.lat - 30}%`,
                        }}
                      >
                        <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-white px-3 py-1.5 rounded-lg shadow-md whitespace-nowrap">
                          <span className="text-sm font-medium text-gray-900">
                            {city}
                          </span>
                          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-2 h-2 bg-white rotate-45"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Map Legend */}
                  <div className="absolute bottom-3 left-3 right-3 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div
                          className={`w-3 h-3 ${coordinates.color} rounded-full mr-2`}
                        ></div>
                        <span className="text-sm text-gray-700">{city}</span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {activity.location}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <p>📍 {activity.location}</p>
                  <p className="mt-1">Approximate location shown on map</p>
                </div>
              </div>

              {/* Booking Card */}
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Book this experience
                </h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-700">Price per person</span>
                    <span className="text-2xl font-bold text-purple-600">
                      {activity.price_range}
                    </span>
                  </div>
                  <button
                    onClick={handleBookNow}
                    className="w-full py-3.5 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-lg hover:opacity-90 transition-all shadow-lg hover:shadow-xl"
                  >
                    Book Now
                  </button>
                </div>
              </div>

              {/* Quick Info */}
              <div className="bg-gray-50 rounded-xl p-5">
                <h4 className="font-semibold text-gray-900 mb-3">
                  Quick facts
                </h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Category</span>
                    <span className="font-medium">{activity.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Age requirement</span>
                    <span className="font-medium">
                      {activity.age_requirement}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Best season</span>
                    <span className="font-medium">{activity.season}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Features</span>
                    <span className="font-medium">
                      {activity.features.length}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Book Now Popup */}
      {showPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 transition-opacity">
          <div className="bg-white rounded-xl p-6 w-96 shadow-2xl relative animate-fade-in">
            <h2 className="text-xl font-semibold mb-4">Confirm Booking</h2>
            <p>
              Do you want to book <strong>{activity.name}</strong> now?
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={handleClosePopup}
                className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert("Booked!");
                  handleClosePopup();
                }}
                className="px-4 py-2 rounded-lg bg-purple-600 text-white hover:bg-purple-700"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ActivityDetail;
