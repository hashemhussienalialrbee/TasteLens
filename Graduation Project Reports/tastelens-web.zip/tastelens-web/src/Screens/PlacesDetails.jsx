import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { api } from "../Auth/api";
import { toast } from "react-toastify";
import {
  FaStar,
  FaMapMarkerAlt,
  FaArrowLeft,
  FaUtensils,
  FaCoffee,
  FaTag,
} from "react-icons/fa";

const PlaceDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [place, setPlace] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPlace();
  }, [id]);

  const fetchPlace = async () => {
    try {
      const res = await api.get(`/places/${id}`);
      setPlace(res.data);
    } catch (err) {
      toast.error("Failed to load place details");
      navigate(-1);
    } finally {
      setLoading(false);
    }
  };

  const getPlaceIcon = (type) => {
    return type?.toLowerCase() === "restaurant" ? (
      <FaUtensils className="text-2xl text-orange-500" />
    ) : (
      <FaCoffee className="text-2xl text-amber-700" />
    );
  };

  const getPlaceImage = () => {
    if (place?.image) return place.image;

    const placeImages = {
      restaurant:
        "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=400&fit=crop",
      cafe: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&h=400&fit=crop",
    };

    const type = place?.type?.toLowerCase();
    if (type && placeImages[type]) {
      return placeImages[type];
    }
    return `https://picsum.photos/800/400?random=${id}`;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-orange-50 to-pink-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500 mx-auto mb-3"></div>
          <p className="text-gray-600">Loading place details...</p>
        </div>
      </div>
    );
  }

  if (!place) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-6 px-4">
      <div className="max-w-2xl mx-auto">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-700 hover:text-purple-600 mb-6 font-medium"
        >
          <FaArrowLeft className="mr-2" />
          Back to Places
        </button>

        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="h-56 w-full overflow-hidden">
            <img
              src={getPlaceImage()}
              alt={place.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-6">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-100 to-pink-100 flex items-center justify-center">
                {getPlaceIcon(place.type)}
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900">
                  {place.name}
                </h1>
                <p className="text-gray-600 text-sm">
                  by {place.owner?.name || "User"}
                </p>
              </div>
              <div className="flex items-center bg-amber-50 text-amber-700 px-3 py-1.5 rounded-lg">
                <FaStar className="mr-1" />
                <span className="font-bold">4.5</span>
              </div>
            </div>

            <div className="mb-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">
                Description
              </h2>
              <p className="text-gray-700">
                {place.description ||
                  "No description available for this place."}
              </p>
            </div>

            <div className="flex items-center gap-2 mb-6 p-3 bg-gray-50 rounded-lg">
              <FaMapMarkerAlt className="text-purple-500" />
              <div>
                <p className="text-sm text-gray-500">Location</p>
                <p className="font-medium text-gray-900">
                  {place.city || "Unknown City"},{" "}
                  {place.country || "Unknown Country"}
                </p>
              </div>
            </div>

            {place.tags && place.tags.length > 0 && (
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <FaTag className="text-gray-500" />
                  <h3 className="font-semibold text-gray-900">Features</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {place.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="bg-gray-100 text-gray-700 px-3 py-1.5 rounded-full text-sm"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="mb-6">
              <h3 className="font-semibold text-gray-900 mb-2">Place Type</h3>
              <span className="inline-block px-4 py-2 bg-purple-100 text-purple-700 rounded-full font-medium">
                {place.type || "Place"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlaceDetails;
