import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../Auth/authProvider";
import { api } from "../Auth/api";
import { toast } from "react-toastify";
import {
  FaRobot,
  FaMagic,
  FaSearch,
  FaSpinner,
  FaCheckCircle,
} from "react-icons/fa";

import StepsIndicator from "../components/StepsIndicator";
import StepMood from "../components/StepMood";
import StepDetails from "../components/StepDetails";
import RecommendationCard from "../components/RecommendationCard";

import {
  getFallbackRecommendations,
  validateUserDetails,
  getRandomImage,
} from "../utils/helpers";

const Home = () => {
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  const [step, setStep] = useState(1);
  const [selectedMood, setSelectedMood] = useState(null);
  const [userDetails, setUserDetails] = useState({
    age: 25,
    budget: "medium",
    city: "Amman",
    relationship_status: "single",
    mood: "",
  });
  const [aiRecommendations, setAiRecommendations] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleMoodSelect = (mood) => {
    setSelectedMood(mood);
    setUserDetails((prev) => ({ ...prev, mood: mood.name.toLowerCase() }));
    setStep(2);
  };

  const handleDetailChange = (field, value) => {
    setUserDetails((prev) => ({ ...prev, [field]: value }));
  };

  const resetFlow = () => {
    setStep(1);
    setSelectedMood(null);
    setUserDetails({
      age: 25,
      budget: "medium",
      city: "Amman",
      relationship_status: "single",
      mood: "",
    });
    setAiRecommendations([]);
  };

  const getAIRecommendations = async () => {
    const error = validateUserDetails(userDetails);
    if (error) {
      toast.error(error);
      return;
    }

    setIsLoading(true);
    setIsSubmitting(true);

    try {
      const response = await api.post("/places/ai-recommend", {
        age: parseInt(userDetails.age),
        budget: userDetails.budget,
        city: userDetails.city,
        mood: userDetails.mood,
        relationship_status: userDetails.relationship_status,
      });

      const recommendationsWithImages = response.data.map((place) => ({
        ...place,
        image: getRandomImage(),
      }));

      setAiRecommendations(recommendationsWithImages);
      setTimeout(() => {
        setStep(3);
        toast.success("🎉 AI recommendations generated successfully!");
      }, 800);
    } catch (error) {
      console.error("AI Recommendation Error:", error);

      const fallbackRecommendations = getFallbackRecommendations(
        userDetails.city
      );

      setAiRecommendations(fallbackRecommendations);
      setTimeout(() => {
        setStep(3);
        toast.info("Showing demo recommendations");
      }, 800);
    } finally {
      setTimeout(() => {
        setIsLoading(false);
        setIsSubmitting(false);
      }, 500);
    }
  };

  const handlePlaceSelect = (place) => {
    navigate(`/place/ai-recommended`, { state: { place } });
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 relative">
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
          <div className="absolute -bottom-20 left-1/2 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
        </div>

        <div className="relative bg-gradient-to-r from-purple-600 via-pink-500 to-rose-500 text-white shadow-2xl z-10">
          <div className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
            <div className="flex items-center">
              <div className="p-3 bg-white/20 rounded-2xl mr-4 backdrop-blur-sm">
                <FaRobot className="text-2xl" />
              </div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">
                  Jordan AI Explorer
                </h1>
                <p className="text-sm opacity-90 mt-1 flex items-center gap-2">
                  <span className="inline-block w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
                  Powered by TasteLensAI
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-semibold">
                Welcome, {user?.first_name || "Explorer"}! 👋
              </div>
              <div className="text-sm opacity-90">
                Personalized recommendations just for you
              </div>
            </div>
          </div>
        </div>

        <main className="relative max-w-7xl mx-auto px-4 py-10 z-10">
          <StepsIndicator step={step} />

          {step === 1 && (
            <StepMood selectedMood={selectedMood} onSelect={handleMoodSelect} />
          )}

          {step === 2 && (
            <StepDetails
              userDetails={userDetails}
              selectedMood={selectedMood}
              onChange={handleDetailChange}
              onNext={getAIRecommendations}
              onBack={() => setStep(1)}
              isLoading={isLoading}
            />
          )}

          {step === 3 && (
            <div className="animate-fadeIn">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-3 bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-white px-8 py-4 rounded-full mb-6 shadow-lg shadow-orange-200">
                  <FaRobot className="text-xl" />
                  <span className="font-bold text-lg tracking-wide">
                    Step 3: AI Recommendations Ready!
                  </span>
                </div>
                <h2 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-amber-600 mb-4">
                  Perfect Places Just For You
                </h2>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                  Based on your{" "}
                  <span className="font-bold text-purple-600">
                    {selectedMood?.name.toLowerCase()}
                  </span>{" "}
                  mood in{" "}
                  <span className="font-bold text-blue-600">
                    {userDetails.city}
                  </span>
                </p>
              </div>

              <div className="mb-10 p-6 bg-gradient-to-r from-amber-50 to-orange-50 rounded-3xl border border-amber-100 shadow-lg">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                  <div>
                    <div className="text-4xl font-bold text-amber-600 mb-2">
                      {aiRecommendations.length}
                    </div>
                    <div className="text-gray-700 font-medium">
                      Recommendations
                    </div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-purple-600 mb-2">
                      {selectedMood?.name}
                    </div>
                    <div className="text-gray-700 font-medium">
                      Selected Mood
                    </div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-emerald-600 mb-2">
                      {userDetails.city}
                    </div>
                    <div className="text-gray-700 font-medium">Location</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-blue-600 mb-2">
                      {userDetails.budget}
                    </div>
                    <div className="text-gray-700 font-medium">
                      Budget Level
                    </div>
                  </div>
                </div>
              </div>

              {isSubmitting ? (
                <div className="text-center py-20">
                  <div className="relative inline-block">
                    <FaSpinner className="text-8xl text-purple-600 animate-spin mx-auto mb-6" />
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 blur-2xl opacity-30"></div>
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-4 mt-8">
                    AI is working its magic... ✨
                  </h3>
                  <p className="text-gray-600 text-lg max-w-md mx-auto">
                    Analyzing preferences and finding perfect places for you in{" "}
                    {userDetails.city}
                  </p>
                </div>
              ) : aiRecommendations.length === 0 ? (
                <div className="text-center py-20 bg-gradient-to-br from-white to-purple-50 rounded-3xl shadow-xl">
                  <div className="text-8xl mb-6">🤔</div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">
                    No recommendations yet
                  </h3>
                  <p className="text-gray-600 text-lg mb-8 max-w-md mx-auto">
                    Start by selecting your mood and preferences
                  </p>
                  <button
                    onClick={resetFlow}
                    className="px-10 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-2xl font-bold hover:opacity-90 shadow-lg hover:shadow-xl transition-all"
                  >
                    Start New Search
                  </button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {aiRecommendations.map((place, index) => (
                      <RecommendationCard
                        key={place.id || index}
                        place={place}
                        selectedMood={selectedMood}
                        onClick={() => handlePlaceSelect(place)}
                        index={index}
                      />
                    ))}
                  </div>

                  <div className="mt-16 text-center space-y-6">
                    <div className="flex flex-col sm:flex-row justify-center gap-6">
                      <button
                        onClick={resetFlow}
                        className="px-10 py-4 bg-gradient-to-r from-gray-600 to-gray-800 text-white rounded-2xl font-bold hover:from-gray-700 hover:to-gray-900 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center gap-3"
                      >
                        <FaMagic className="text-lg" />
                        Start New Search
                      </button>
                      <button
                        onClick={() => navigate("/activities")}
                        className="px-10 py-4 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-2xl font-bold hover:from-blue-600 hover:to-cyan-600 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center gap-3"
                      >
                        <FaSearch className="text-lg" />
                        Explore All Activities
                      </button>
                    </div>
                    <p className="text-gray-500 text-sm italic">
                      Click on any card to view detailed information about the
                      place
                    </p>
                  </div>
                </>
              )}
            </div>
          )}

          <div className="mt-20 bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl p-10 text-white shadow-2xl backdrop-blur-sm bg-opacity-90">
            <div className="text-center mb-8">
              <h3 className="text-3xl font-bold mb-3">
                Jordan AI Explorer Stats
              </h3>
              <p className="opacity-90 text-lg">Real-time AI Personalization</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div className="bg-white/10 p-8 rounded-3xl backdrop-blur-sm hover:bg-white/20 transition-all duration-300">
                <div className="text-5xl font-bold mb-3">6</div>
                <div className="text-lg font-medium">Available Moods</div>
              </div>
              <div className="bg-white/10 p-8 rounded-3xl backdrop-blur-sm hover:bg-white/20 transition-all duration-300">
                <div className="text-5xl font-bold mb-3">
                  {aiRecommendations.length}
                </div>
                <div className="text-lg font-medium">AI Recommendations</div>
              </div>
              <div className="bg-white/10 p-8 rounded-3xl backdrop-blur-sm hover:bg-white/20 transition-all duration-300">
                <div className="text-5xl font-bold mb-3">100%</div>
                <div className="text-lg font-medium">Personalized</div>
              </div>
              <div className="bg-white/10 p-8 rounded-3xl backdrop-blur-sm hover:bg-white/20 transition-all duration-300">
                <div className="text-5xl font-bold mb-3">24/7</div>
                <div className="text-lg font-medium">AI Available</div>
              </div>
            </div>

            <div className="text-center mt-10 text-sm opacity-80">
              <p className="text-lg">
                ✨ AI recommendations are generated in real-time based on your
                unique preferences and mood
              </p>
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default Home;
