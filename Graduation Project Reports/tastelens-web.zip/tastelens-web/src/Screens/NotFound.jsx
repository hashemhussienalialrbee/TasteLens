import { Link } from "react-router-dom";
import { FaHome, FaUtensils } from "react-icons/fa";

const NotFound = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 to-pink-50 p-4">
      <div className="max-w-md w-full text-center">
        <div className="flex items-center justify-center space-x-2 mb-8">
          <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full flex items-center justify-center">
            <FaUtensils className="w-5 h-5 text-white" />
          </div>
          <span className="text-2xl font-bold text-gray-900">TasteLens</span>
        </div>

        <div className="mb-6">
          <h1 className="text-8xl font-bold bg-gradient-to-r from-purple-400 to-purple-300 bg-clip-text text-transparent">
            404
          </h1>
          <h2 className="text-2xl font-semibold text-gray-800 mt-2">
            Page Not Found
          </h2>
          <p className="text-gray-600 mt-3">
            Oops! The page you're looking for doesn't exist.
          </p>
        </div>

        <div className="mb-8">
          <div className="w-32 h-32 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full mx-auto flex items-center justify-center text-5xl">
            🍴
          </div>
        </div>

        <Link
          to="/"
          className="inline-flex items-center space-x-2 bg-gradient-to-r from-purple-400 to-purple-300 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg transition-all hover:scale-105"
        >
          <FaHome className="w-5 h-5" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
