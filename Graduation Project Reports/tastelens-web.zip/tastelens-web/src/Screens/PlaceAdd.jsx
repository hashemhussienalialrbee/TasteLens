import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../Auth/authProvider";
import { api } from "../Auth/api";
import { toast } from "react-toastify";
import {
  FaArrowLeft,
  FaMapMarkerAlt,
  FaUtensils,
  FaCoffee,
  FaDollarSign,
  FaGlobe,
} from "react-icons/fa";

const PlaceAdd = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    type: "cafe",
    description: "",
    city: "",
    country: "",
    budget: "",
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const placeTypes = [
    {
      value: "cafe",
      label: "Cafe",
      icon: <FaCoffee className="text-amber-700" />,
    },
    {
      value: "restaurant",
      label: "Restaurant",
      icon: <FaUtensils className="text-orange-500" />,
    },
  ];

  const budgetOptions = ["$", "$$", "$$$", "$$$$"];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validateForm = () => {
    const newErrors = {};
    ["name", "description", "city", "country", "budget"].forEach((field) => {
      if (!formData[field].trim()) newErrors[field] = "Required";
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return toast.error("Please fill all required fields");

    setLoading(true);
    try {
      await api.post("/places", formData);
      toast.success("Place added successfully!");
      setFormData({
        name: "",
        type: "cafe",
        description: "",
        city: "",
        country: "",
        budget: "",
      });
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to add place");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center text-purple-600 hover:text-purple-800 mb-6"
        >
          <FaArrowLeft className="mr-2" /> Back
        </button>

        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <FaMapMarkerAlt className="text-2xl text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Share Your Favorite Place
          </h1>
          <p className="text-gray-600">Help others discover amazing spots</p>
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl shadow-xl p-6 md:p-8 space-y-6"
        >
          <InputField
            label="Place Name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            error={errors.name}
            placeholder="Enter place name"
          />
          <InputField
            label="Description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            error={errors.description}
            placeholder="What makes it special?"
            textarea
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField
              label="City"
              name="city"
              value={formData.city}
              onChange={handleChange}
              error={errors.city}
              icon={<FaMapMarkerAlt className="text-gray-400" />}
            />
            <InputField
              label="Country"
              name="country"
              value={formData.country}
              onChange={handleChange}
              error={errors.country}
              icon={<FaGlobe className="text-gray-400" />}
            />
          </div>

          {/* Place Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Place Type
            </label>
            <div className="grid grid-cols-2 gap-3">
              {placeTypes.map((type) => (
                <button
                  key={type.value}
                  type="button"
                  onClick={() =>
                    setFormData((prev) => ({ ...prev, type: type.value }))
                  }
                  className={`flex items-center justify-center gap-2 py-3 rounded-lg border transition-all ${
                    formData.type === type.value
                      ? "bg-gradient-to-r from-purple-100 to-pink-100 border-purple-500 text-purple-700"
                      : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  {type.icon} {type.label}
                </button>
              ))}
            </div>
          </div>

          {/* Budget */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Price Range
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {budgetOptions.map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() =>
                    setFormData((prev) => ({ ...prev, budget: b }))
                  }
                  className={`flex items-center justify-center gap-2 py-3 rounded-lg border transition-all ${
                    formData.budget === b
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white border-transparent"
                      : "bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <FaDollarSign /> {b}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg font-semibold text-white text-lg bg-gradient-to-r from-purple-500 to-pink-500 hover:shadow-lg hover:scale-[1.02] transition-all"
          >
            {loading ? "Adding..." : "Add Place"}
          </button>
        </form>
      </div>
    </div>
  );
};

const InputField = ({
  label,
  name,
  value,
  onChange,
  error,
  placeholder,
  textarea,
  icon,
}) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-2">
      {label} *
    </label>
    <div className="relative">
      {icon && (
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          {icon}
        </div>
      )}
      {textarea ? (
        <textarea
          name={name}
          value={value}
          onChange={onChange}
          rows="4"
          placeholder={placeholder}
          className={`w-full ${
            icon ? "pl-10" : "px-4"
          } pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
            error ? "border-red-500" : "border-gray-300"
          }`}
        />
      ) : (
        <input
          type="text"
          name={name}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          className={`w-full ${
            icon ? "pl-10" : "px-4"
          } pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent ${
            error ? "border-red-500" : "border-gray-300"
          }`}
        />
      )}
    </div>
    {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
  </div>
);

export default PlaceAdd;
