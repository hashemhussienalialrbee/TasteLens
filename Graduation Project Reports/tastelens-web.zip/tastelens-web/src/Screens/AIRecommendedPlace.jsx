import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import {
  FaMapMarkerAlt,
  FaMoneyBillWave,
  FaRobot,
  FaArrowLeft,
  FaExternalLinkAlt,
  FaCalendarCheck,
} from "react-icons/fa";

const AIRecommendedPlace = () => {
  const { state } = useLocation();
  const navigate = useNavigate();

  const place = state?.place;

  if (!place) {
    navigate("/home");
    return null;
  }

  const getPlaceTypeColor = (type) => {
    switch (type) {
      case "cafe":
        return "bg-amber-500";
      case "restaurant":
        return "bg-red-500";
      default:
        return "bg-purple-500";
    }
  };

  const getBudgetColor = (budget) => {
    switch (budget) {
      case "low":
        return "bg-green-500";
      case "medium":
        return "bg-yellow-500";
      case "high":
        return "bg-red-500";
      default:
        return "bg-gray-500";
    }
  };

  const handleBook = () => {
    toast.success("✅ Booking request sent successfully!", {
      position: "top-center",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Navigation */}
        <button
          onClick={() => navigate("/home")}
          className="flex items-center text-purple-600 hover:text-purple-800 mb-8"
        >
          <FaArrowLeft className="mr-2" />
          Back to AI Recommendations
        </button>

        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className={`p-8 text-white ${getPlaceTypeColor(place.type)}`}>
            <div className="flex justify-between items-start">
              <div>
                <div className="text-sm font-bold opacity-80 mb-2">
                  AI RECOMMENDED PLACE
                </div>
                <h1 className="text-3xl font-bold mb-4">{place.name}</h1>

                <div className="flex items-center gap-4">
                  <div
                    className={`px-4 py-2 rounded-full ${getBudgetColor(
                      place.budget
                    )}`}
                  >
                    <span className="font-bold">
                      {place.budget.toUpperCase()} BUDGET
                    </span>
                  </div>

                  <div className="bg-white/20 px-4 py-2 rounded-full">
                    <span className="font-bold">
                      {place.type.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="text-4xl">
                {place.type === "cafe" ? "☕" : "🍽️"}
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-8">
            {/* AI Reason */}
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 mb-8 border border-purple-200">
              <div className="flex items-start">
                <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg mr-4">
                  <FaRobot className="text-white text-xl" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 text-lg mb-2">
                    AI Recommendation Reason
                  </h3>
                  <p className="text-gray-700">{place.reason}</p>
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="mb-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                About This Place
              </h3>
              <p className="text-gray-700 text-lg leading-relaxed">
                {place.description}
              </p>
            </div>

            {/* Details */}
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-gray-50 p-6 rounded-xl">
                <div className="flex items-center mb-4">
                  <FaMapMarkerAlt className="text-purple-600 mr-3 text-xl" />
                  <h4 className="font-bold text-gray-900 text-lg">Location</h4>
                </div>
                <p className="text-gray-700">{place.location}</p>
              </div>

              <div className="bg-gray-50 p-6 rounded-xl">
                <div className="flex items-center mb-4">
                  <FaMoneyBillWave className="text-green-600 mr-3 text-xl" />
                  <h4 className="font-bold text-gray-900 text-lg">
                    Budget Level
                  </h4>
                </div>

                <div
                  className={`inline-block px-4 py-2 ${getBudgetColor(
                    place.budget
                  )} text-white rounded-full font-bold`}
                >
                  {place.budget.toUpperCase()}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-4 flex-wrap">
              <button
                onClick={() =>
                  window.open(
                    `https://maps.google.com/?q=${place.location}`,
                    "_blank"
                  )
                }
                className="flex-1 py-4 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-xl font-bold hover:opacity-90 flex items-center justify-center gap-3"
              >
                <FaMapMarkerAlt />
                Open in Google Maps
                <FaExternalLinkAlt className="text-sm" />
              </button>

              <button
                onClick={() => navigate("/home")}
                className="flex-1 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-bold hover:opacity-90 flex items-center justify-center gap-3"
              >
                <FaRobot />
                Get More Recommendations
              </button>

              <button
                onClick={handleBook}
                className="flex-1 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-xl font-bold hover:opacity-90 flex items-center justify-center gap-3"
              >
                <FaCalendarCheck />
                Book Now
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-gray-500 text-sm">
          <p>
            ℹ️ This recommendation was generated by AI based on your
            preferences. Details may vary in reality.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AIRecommendedPlace;
