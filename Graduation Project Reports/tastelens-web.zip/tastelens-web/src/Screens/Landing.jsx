import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import RestaurantCard from "../components/UI/RestaurantCard";
import {
  restaurants,
  landingHero,
  landingStats,
  landingSteps,
} from "../data/LandingData";

const Landing = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen font-sans overflow-hidden bg-white relative">
      <section className="relative py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 via-pink-500/15 to-orange-400/10"></div>

          {landingHero.gradientCircles.map((circle, idx) => (
            <div
              key={idx}
              className={`absolute ${circle.top ? `top-${circle.top}` : ""} ${
                circle.bottom ? `bottom-${circle.bottom}` : ""
              } ${circle.left ? `left-${circle.left}` : ""} ${
                circle.right ? `right-${circle.right}` : ""
              } 
              w-${circle.w} h-${circle.h} rounded-full bg-gradient-to-r from-${
                circle.from
              } to-${circle.to} animate-${circle.animation} opacity-${
                circle.opacity
              }`}
            ></div>
          ))}
        </div>

        <div className="container mx-auto max-w-6xl relative z-10 text-center">
          <div
            className={`transition-transform duration-1000 ease-out ${
              isVisible
                ? "translate-y-0 opacity-100"
                : "translate-y-10 opacity-0"
            }`}
          >
            <h1 className="text-6xl md:text-8xl font-bold mb-4 tracking-tight text-gray-900">
              {landingHero.title}
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Lens
              </span>
            </h1>
            <div className="h-1 w-32 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto rounded-full mb-6"></div>
            <p className="text-2xl md:text-4xl mb-8 font-light text-gray-800">
              <span className="font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Discover & Savor
              </span>{" "}
              extraordinary culinary journeys
            </p>
            <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              {landingHero.description}
            </p>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Link
                to="/signup"
                className="group relative overflow-hidden bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-5 rounded-full text-xl font-semibold shadow-2xl hover:shadow-purple-500/30 transition-transform duration-500 hover:scale-105 hover:-translate-y-1 inline-block"
              >
                <span className="relative z-10">Start Your Journey →</span>
              </Link>
              <Link
                to="/about-us"
                className="group relative bg-white/80 backdrop-blur-sm text-gray-800 px-10 py-5 rounded-full text-xl font-semibold border-2 border-purple-200 hover:border-purple-400 hover:bg-white transition-transform duration-300 hover:scale-105 shadow-lg hover:shadow-xl"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Who We Are{" "}
                  <span className="group-hover:translate-x-2 transition-transform">
                    ↗
                  </span>
                </span>
              </Link>
            </div>
          </div>

          {/* Stats Section */}
          <div
            className={`mt-24 grid grid-cols-2 md:grid-cols-4 gap-8 transition-transform duration-1000 ease-out ${
              isVisible
                ? "translate-y-0 opacity-100"
                : "translate-y-10 opacity-0"
            }`}
          >
            {landingStats.map((stat, idx) => (
              <div key={idx} className="text-center group cursor-pointer">
                <div
                  className={`mb-3 text-4xl md:text-5xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}
                >
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium group-hover:text-gray-900 transition-colors">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Restaurants Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-white to-purple-50">
        <div className="container mx-auto">
          <div
            className={`text-center mb-16 transition-transform duration-700 ease-out ${
              isVisible
                ? "translate-y-0 opacity-100"
                : "translate-y-10 opacity-0"
            }`}
          >
            <h2 className="text-5xl font-bold text-gray-900 mb-6">
              Featured{" "}
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Destinations
              </span>
            </h2>
            <p className="text-gray-600 text-xl max-w-3xl mx-auto">
              Curated collections based on trending moods, seasons, and foodie
              favorites
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {restaurants.map((restaurant, idx) => (
              <div
                key={restaurant.id}
                className={`transform transition-transform duration-500 ease-out hover:scale-105 ${
                  isVisible
                    ? "translate-y-0 opacity-100"
                    : "translate-y-10 opacity-0"
                }`}
                style={{ transitionDelay: `${idx * 100}ms` }}
              >
                <RestaurantCard {...restaurant} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-purple-50 to-white">
        <div className="container mx-auto max-w-6xl">
          <div
            className={`text-center mb-20 transition-transform duration-700 ease-out ${
              isVisible
                ? "translate-y-0 opacity-100"
                : "translate-y-10 opacity-0"
            }`}
          >
            <h2 className="text-5xl font-bold text-gray-900 mb-6">
              How{" "}
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                TasteLens
              </span>{" "}
              Works
            </h2>
            <p className="text-gray-600 text-xl max-w-3xl mx-auto">
              Your personal guide to unforgettable dining experiences
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {landingSteps.map((step, idx) => (
              <div
                key={idx}
                className={`group relative transform transition-transform duration-700 ease-out hover:shadow-2xl ${
                  isVisible
                    ? "translate-y-0 opacity-100"
                    : "translate-y-10 opacity-0"
                }`}
                style={{ transitionDelay: `${500 + idx * 150}ms` }}
              >
                <div className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100 hover:border-purple-200">
                  <div className="flex items-center gap-4 mb-6">
                    <div
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${step.color} flex items-center justify-center text-2xl`}
                    >
                      {step.icon}
                    </div>
                    <div className="text-5xl font-bold text-gray-300">
                      {step.step}
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {step.description}
                  </p>
                  <div className="mt-8 pt-6 border-t border-gray-100">
                    <div className="h-1 w-0 group-hover:w-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-700 rounded-full"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Landing;
