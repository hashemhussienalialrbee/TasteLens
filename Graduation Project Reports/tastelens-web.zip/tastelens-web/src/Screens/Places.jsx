import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../Auth/api";
import { toast } from "react-toastify";
import {
  FaStar,
  FaMapMarkerAlt,
  FaTag,
  FaFilter,
  FaArrowRight,
  FaUtensils,
  FaCoffee,
} from "react-icons/fa";

const UserPlaces = () => {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filteredCategory, setFilteredCategory] = useState("All");
  const navigate = useNavigate();

  useEffect(() => {
    fetchPlaces();
  }, []);

  const fetchPlaces = async () => {
    try {
      const res = await api.get("/places/user");
      setPlaces(res.data);
    } catch (err) {
      toast.error("Failed to load places");
    } finally {
      setLoading(false);
    }
  };

  const getPlaceImage = (place) => {
    const placeImages = {
      restaurant: [
        "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1559329007-40df8a9345d8?w=800&h=600&fit=crop",
      ],
      cafe: [
        "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&h=600&fit=crop",
        "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&h=600&fit=crop",
      ],
    };

    const type = place.type?.toLowerCase();
    if (type && placeImages[type]) {
      return placeImages[type][place.id % 2];
    }
    return `https://picsum.photos/800/600?random=${place.id}`;
  };

  const getPlaceIcon = (type) => {
    return type?.toLowerCase() === "restaurant" ? (
      <FaUtensils className="text-orange-500" />
    ) : type?.toLowerCase() === "cafe" ? (
      <FaCoffee className="text-amber-700" />
    ) : (
      <FaMapMarkerAlt className="text-purple-500" />
    );
  };

  const categories = [
    "All",
    ...new Set(places.map((place) => place.type).filter(Boolean)),
  ];

  const filteredPlaces =
    filteredCategory === "All"
      ? places
      : places.filter((place) => place.type === filteredCategory);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500 mx-auto mb-3"></div>
          <p className="text-gray-600">Loading places...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-6 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-purple-600 hover:text-purple-800 mb-4"
          >
            <span className="text-xl mr-1">←</span> Back
          </button>

          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-4xl font-bold">Discover Amazing Places 🌍</h1>
              <p className="text-gray-600">
                Explore unique destinations shared by our community
              </p>
            </div>
            <div className="bg-white px-4 py-2 rounded-full shadow">
              <span className="font-bold text-purple-600">{places.length}</span>{" "}
              places
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6 mb-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-700">
              <p className="font-medium">
                Want to add a new place? Our team will review it and you'll get
                an email if approved.
              </p>
            </div>
            <button
              onClick={() => navigate("/place-add")}
              className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl shadow-lg hover:scale-105 transition-all font-semibold"
            >
              + Add Place
            </button>
          </div>
        </div>

        <div className="mb-6 bg-white rounded-xl p-4 shadow">
          <div className="flex items-center gap-2 mb-3">
            <FaFilter className="text-purple-600" />
            <h2 className="font-semibold text-gray-900">Filter by Type</h2>
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setFilteredCategory(category)}
                className={`px-4 py-2 rounded-full ${
                  filteredCategory === category
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Places Grid */}
        {filteredPlaces.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl shadow">
            <FaMapMarkerAlt className="text-4xl text-gray-400 mx-auto mb-3" />
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              No places found
            </h3>
            <p className="text-gray-600 mb-4">
              {filteredCategory === "All"
                ? "No places added yet"
                : `No ${filteredCategory} places`}
            </p>
            <button
              onClick={() => setFilteredCategory("All")}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg"
            >
              Show All
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredPlaces.map((place) => (
              <div
                key={place.id}
                className="bg-white rounded-xl overflow-hidden shadow hover:shadow-md transition-shadow"
              >
                {/* Place Image */}
                <div className="h-48 overflow-hidden">
                  <img
                    src={getPlaceImage(place)}
                    alt={place.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                  <div className="relative -mt-8 mx-4 flex justify-between">
                    <div className="bg-white px-3 py-1 rounded-full shadow">
                      <span className="text-sm font-medium">{place.type}</span>
                    </div>
                    <div className="bg-white px-3 py-1 rounded-full shadow flex items-center gap-1">
                      <FaStar className="text-amber-500" />
                      <span className="font-medium">4.5</span>
                    </div>
                  </div>
                </div>

                {/* Place Content */}
                <div className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center">
                      {getPlaceIcon(place.type)}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-gray-900 truncate">
                        {place.name}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {place.owner?.name || "User"}
                      </p>
                    </div>
                  </div>

                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                    {place.description || "No description"}
                  </p>

                  <div className="flex items-center text-sm text-gray-500 mb-3">
                    <FaMapMarkerAlt className="mr-2 text-purple-500" />
                    <span className="truncate">
                      {place.city || "City"}, {place.country || "Country"}
                    </span>
                  </div>

                  {place.tags?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {place.tags.slice(0, 2).map((tag, index) => (
                        <span
                          key={index}
                          className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  <button
                    onClick={() => navigate(`/places/${place.id}`)}
                    className="w-full flex items-center justify-center gap-2 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:shadow transition-all"
                  >
                    <span>View Details</span>
                    <FaArrowRight className="text-xs" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default UserPlaces;
