import React from "react";
import { statCards, activity } from "../../data/DashboardData";

const Dashboard = () => {
  const stats = {
    totalUsers: 300,
    newMessages: 5,
    totalRestaurants: 42,
    activeToday: 289,
    satisfactionRate: 94,
    monthlyGrowth: 23,
  };

  return (
    <div>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Your platform's overview</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map(({ key, label, icon: Icon, color }) => (
          <div
            key={key}
            className={`bg-gradient-to-br ${color} p-6 rounded-2xl text-white shadow-lg`}
          >
            <div className="flex justify-between items-start">
              <div>
                <p className="text-lg opacity-90">{label}</p>
                <p className="text-4xl font-bold mt-2">
                  {stats[key]}
                  {key.includes("Rate") || key.includes("Growth") ? "%" : ""}
                </p>
              </div>
              <div className="bg-white/20 p-3 rounded-full">
                <Icon className="text-2xl" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-10">
        {/* Recent Activity */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h2 className="text-xl font-bold mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {activity.map((a, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                    {a.icon}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{a.text}</p>
                    <p className="text-sm text-gray-500">{a.time}</p>
                  </div>
                </div>
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl shadow-lg p-6">
          <h2 className="text-xl font-bold mb-6">Platform Stats</h2>

          <div className="space-y-4">
            {[
              { label: "Avg Rating", value: "4.8", icon: "⭐" },
              { label: "Response Time", value: "2.4h", icon: "🔄" },
              { label: "Uptime", value: "99.9%", icon: "🚀" },
            ].map((item, i) => (
              <div
                key={i}
                className="flex items-center justify-between bg-white p-3 rounded-lg shadow-sm"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                    {item.icon}
                  </div>
                  <div>
                    <p className="font-medium">{item.label}</p>
                    <p className="text-sm text-gray-500">Updated stats</p>
                  </div>
                </div>
                <span className="text-lg font-bold text-purple-600">
                  {item.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
