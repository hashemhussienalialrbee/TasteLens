import React, { useEffect, useState } from "react";
import { api } from "../../Auth/api";
import { toast } from "react-toastify";

const AdminPlaces = () => {
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [currentPlace, setCurrentPlace] = useState(null);
  const [editName, setEditName] = useState("");
  const [editDescription, setEditDescription] = useState("");

  useEffect(() => {
    fetchPlaces();
  }, []);

  const fetchPlaces = async () => {
    try {
      const res = await api.get("/places/admin");
      setPlaces(res.data);
    } catch {
      toast.error("Failed to load places");
    } finally {
      setLoading(false);
    }
  };

  const approvePlace = async (id) => {
    try {
      await api.patch(`/places/${id}/approve`);
      toast.success("Place approved");
      fetchPlaces();
    } catch {
      toast.error("Failed to approve place");
    }
  };

  const rejectPlace = async (id) => {
    try {
      await api.patch(`/places/${id}/reject`);
      toast.success("Place rejected");
      fetchPlaces();
    } catch {
      toast.error("Failed to reject place");
    }
  };

  const openEditModal = (place) => {
    setCurrentPlace(place);
    setEditName(place.name);
    setEditDescription(place.description);
    setEditModalOpen(true);
  };

  const saveEdit = async () => {
    try {
      await api.patch(`/places/${currentPlace.id}`, {
        name: editName,
        description: editDescription,
      });
      toast.success("Place updated");
      setEditModalOpen(false);
      fetchPlaces();
    } catch {
      toast.error("Failed to update place");
    }
  };

  if (loading) return <div className="text-center py-20">Loading...</div>;

  const getStatusClass = (status) => {
    if (status === "active") return "bg-green-100 text-green-800";
    if (status === "rejected") return "bg-red-100 text-red-800";
    return "bg-yellow-100 text-yellow-800";
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Places ({places.length})</h1>

      {/* ===== Desktop Table ===== */}
      <div className="hidden md:block bg-white rounded-xl shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Type</th>
              <th className="px-4 py-3 text-left">Owner</th>
              <th className="px-4 py-3 text-left">Location</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {places.map((place) => (
              <tr key={place.id}>
                <td className="px-4 py-3 font-medium">
                  {place.name}
                  <p className="text-sm text-gray-500">{place.description}</p>
                </td>
                <td className="px-4 py-3">{place.type}</td>
                <td className="px-4 py-3">
                  {place.account.first_name} {place.account.last_name}
                </td>
                <td className="px-4 py-3">
                  {place.city || "-"} / {place.country || "-"}
                </td>
                <td className="px-4 py-3">
                  <span
                    className={`px-3 py-1 rounded-full text-sm ${getStatusClass(
                      place.status
                    )}`}
                  >
                    {place.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-center space-x-2">
                  {place.status === "pending" || place.status === "rejected" ? (
                    <>
                      <button
                        onClick={() => approvePlace(place.id)}
                        className="bg-green-600 text-white px-3 py-1 rounded"
                      >
                        Approve
                      </button>
                      {place.status === "pending" && (
                        <button
                          onClick={() => rejectPlace(place.id)}
                          className="bg-red-600 text-white px-3 py-1 rounded"
                        >
                          Reject
                        </button>
                      )}
                    </>
                  ) : (
                    <button
                      onClick={() => openEditModal(place)}
                      className="bg-blue-600 text-white px-3 py-1 rounded"
                    >
                      Edit
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== Mobile Cards ===== */}
      <div className="md:hidden space-y-4">
        {places.map((place) => (
          <div key={place.id} className="bg-white rounded-xl shadow p-4">
            <h3 className="font-bold text-lg">{place.name}</h3>
            <p className="text-sm text-gray-500 mb-2">{place.description}</p>

            <div className="text-sm space-y-1">
              <p>
                <b>Type:</b> {place.type}
              </p>
              <p>
                <b>Owner:</b> {place.account.first_name}{" "}
                {place.account.last_name}
              </p>
              <p>
                <b>Location:</b> {place.city || "-"} / {place.country || "-"}
              </p>
            </div>

            <div className="mt-3 flex items-center justify-between">
              <span
                className={`px-3 py-1 rounded-full text-sm ${getStatusClass(
                  place.status
                )}`}
              >
                {place.status}
              </span>

              <div className="space-x-2">
                {place.status === "pending" || place.status === "rejected" ? (
                  <>
                    <button
                      onClick={() => approvePlace(place.id)}
                      className="bg-green-600 text-white px-3 py-1 rounded"
                    >
                      ✔
                    </button>
                    {place.status === "pending" && (
                      <button
                        onClick={() => rejectPlace(place.id)}
                        className="bg-red-600 text-white px-3 py-1 rounded"
                      >
                        ✖
                      </button>
                    )}
                  </>
                ) : (
                  <button
                    onClick={() => openEditModal(place)}
                    className="bg-blue-600 text-white px-3 py-1 rounded"
                  >
                    Edit
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ===== Edit Modal ===== */}
      {editModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-96">
            <h2 className="text-xl font-bold mb-4">Edit Place</h2>
            <div className="space-y-3">
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Name"
                className="w-full border rounded px-3 py-2"
              />
              <textarea
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                placeholder="Description"
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div className="mt-4 flex justify-end space-x-2">
              <button
                onClick={() => setEditModalOpen(false)}
                className="px-4 py-2 rounded bg-gray-300"
              >
                Cancel
              </button>
              <button
                onClick={saveEdit}
                className="px-4 py-2 rounded bg-blue-600 text-white"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPlaces;
