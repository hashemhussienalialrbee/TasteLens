import React, { useState, useEffect } from "react";
import { api } from "../../Auth/api";

const Users = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await api.get("/users");

      if (!response.data) {
        setError("No data received from server");
        return;
      }

      const data = response.data;

      if (!Array.isArray(data)) {
        console.error("Expected array but got:", typeof data);
        setError("Invalid data format from server");
        return;
      }

      const accounts = data
        .map((item) => {
          return item.account;
        })
        .filter((account) => account);

      setUsers(accounts);
    } catch (error) {
      console.error("Error fetching users:", error);
      setError(error.message || "Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        <span className="ml-4 text-gray-600">Loading users...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-500 text-xl mb-4">⚠️ Error: {error}</div>
        <button
          onClick={fetchUsers}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-2">
        Users ({users.length})
      </h1>
      <p className="text-gray-600 mb-8">All registered users</p>

      {users.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-2xl">
          <div className="text-5xl mb-4">👤</div>
          <p className="text-gray-600 text-lg">No users found</p>
          <p className="text-gray-500">The API returned 0 users.</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-sm text-gray-700">
                  ID
                </th>
                <th className="px-6 py-3 text-left text-sm text-gray-700">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-sm text-gray-700">
                  Email
                </th>
                <th className="px-6 py-3 text-left text-sm text-gray-700">
                  Phone
                </th>
                <th className="px-6 py-3 text-left text-sm text-gray-700">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-sm text-gray-700">
                  Joined
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {users.map((user) => {
                return (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-gray-500">#{user.id}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full flex items-center justify-center mr-3">
                          <span className="text-white font-medium">
                            {user.first_name?.charAt(0) || "U"}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">
                            {user.first_name} {user.last_name}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-600">{user.email}</td>
                    <td className="px-6 py-4 text-gray-600">
                      {user.phone_number || "N/A"}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          user.account_type === "admin"
                            ? "bg-purple-100 text-purple-800"
                            : user.account_type === "user"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {user.account_type}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-500">
                      {user.created_at
                        ? new Date(user.created_at).toLocaleDateString()
                        : "N/A"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Users;
