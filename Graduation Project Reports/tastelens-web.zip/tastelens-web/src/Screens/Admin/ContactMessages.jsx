import React, { useState, useEffect } from "react";
import { api } from "../../Auth/api";

const ContactMessages = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      console.log("Fetching contact messages...");
      const response = await api.get("/contact-us");

      setMessages(response.data || []);
    } catch (error) {
      console.error("Error fetching messages:", error);
      setError("Failed to load messages");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-500 text-xl mb-4">⚠️ {error}</div>
        <button
          onClick={fetchMessages}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-2">
        Contact Messages ({messages.length})
      </h1>
      <p className="text-gray-600 mb-8">All contact form submissions</p>

      {messages.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-2xl">
          <div className="text-5xl mb-4">📭</div>
          <p className="text-gray-600 text-lg">No messages found</p>
          <p className="text-gray-500">No contact form submissions yet.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className="bg-white rounded-2xl p-6 shadow hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className="font-medium text-gray-900">{message.email}</p>
                  <p className="text-gray-500 text-sm">
                    {message.phone_number}
                  </p>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${
                    message.type === "support"
                      ? "bg-green-100 text-green-800"
                      : message.type === "technical"
                      ? "bg-red-100 text-red-800"
                      : "bg-blue-100 text-blue-800"
                  }`}
                >
                  {message.type}
                </span>
              </div>

              <p className="text-gray-700 mb-4">{message.message}</p>

              <div className="flex justify-between items-center text-sm text-gray-500">
                <span>
                  📅 {new Date(message.created_at).toLocaleDateString()}
                </span>
                <span>
                  🕐{" "}
                  {new Date(message.created_at).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ContactMessages;
