import React from "react";

const About = () => {
  const teamMembers = [
    "Hashem Alrabee",
    "Asem Abu Diak",
    "Heba Mahaftha",
    "Ekhlas AL-khaldy",
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-12">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            About TasteLens
          </h1>
          <p className="text-gray-600 text-lg">
            Discover restaurants based on how you feel
          </p>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-3xl shadow-xl p-8">
            <div className="flex items-center gap-3 mb-6">
              <span className="text-2xl">✨</span>
              <h2 className="text-2xl font-bold text-gray-900">Our Story</h2>
            </div>
            <p className="text-gray-700 mb-4">
              TasteLens was created with one simple idea: finding the perfect
              place to eat should be about how you feel, not just about ratings
              and reviews.
            </p>
            <p className="text-gray-700">
              We believe that your mood should guide your dining choices,
              whether you're celebrating, relaxing, or just need comfort food.
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-xl p-8">
            <div className="flex items-center gap-3 mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Our Team</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {teamMembers.map((member, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                >
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                    <span className="text-purple-600 font-semibold">
                      {member.charAt(0)}
                    </span>
                  </div>
                  <span className="text-gray-800 font-medium">{member}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-xl p-8">
            <div className="flex items-center gap-3 mb-6">
              <span className="text-2xl">🎯</span>
              <h2 className="text-2xl font-bold text-gray-900">What We Do</h2>
            </div>
            <p className="text-gray-700 mb-4">
              We connect people with restaurants, activities that match their
              emotional state. Simply tell us how you're feeling, and we'll show
              you the perfect spots.
            </p>
            <p className="text-gray-700">
              From cozy cafes to fine dining, we've curated experiences for
              every mood.
            </p>
            <div className="mt-6">
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop"
                alt="Restaurant"
                className="w-full h-48 object-cover rounded-2xl"
              />
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-400 to-purple-300 rounded-3xl shadow-xl p-8 text-white">
            <div className="flex items-center gap-3 mb-6">
              <span className="text-3xl">🇯🇴</span>
              <h2 className="text-2xl font-bold">Proudly Jordanian</h2>
            </div>
            <p className="mb-4 text-purple-100">
              TasteLens is 100% Jordanian. We feature restaurants and cafes from
              all across Jordan, supporting local businesses and showcasing
              authentic Jordanian hospitality.
            </p>
            <p className="text-purple-100">
              From Amman to Aqaba, from Irbid to Petra, we're connecting people
              with the best of Jordan.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
