import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { api } from "../../Auth/api";
import { toast } from "react-toastify";

const ResetPassword = () => {
  const [formData, setFormData] = useState({
    password: "",
    confirmPassword: "",
  });
  const [isReset, setIsReset] = useState(false);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();

  const token_id = location.state?.token_id;

  if (!token_id && !isReset) {
    toast.error("No token found. Please verify OTP again.");
    navigate("/verify-otp");
    return null;
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const passwordsMatch =
    formData.password === formData.confirmPassword && formData.password !== "";

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!passwordsMatch) {
      toast.error("Passwords do not match!");
      return;
    }

    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(formData.password)) {
      toast.error(
        "Password must be at least 8 characters and include letters and numbers."
      );
      return;
    }

    setLoading(true);
    try {
      const { data } = await api.post("/accounts/reset-password", {
        new_password: formData.password,
        token_id: token_id,
      });

      toast.success(data.message || "Password reset successfully!");
      setIsReset(true);
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Failed to reset password. Try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-purple-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full">
        <div className="p-8 md:p-12">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-2xl text-white">🔄</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">TasteLens</h1>
          </div>

          {!isReset ? (
            <>
              <h2 className="text-3xl font-bold mb-2 text-gray-900">
                Set New Password
              </h2>
              <p className="text-gray-600 mb-8">
                Create a new password for your account.
              </p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    New Password
                  </label>
                  <input
                    type="password"
                    name="password"
                    placeholder="Enter new password"
                    value={formData.password}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-purple-400 transition-colors"
                    required
                    disabled={loading}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Must be at least 8 characters with letters and numbers
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    name="confirmPassword"
                    placeholder="Confirm new password"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-purple-400 transition-colors"
                    required
                    disabled={loading}
                  />
                  {formData.confirmPassword && (
                    <p
                      className={`text-sm mt-1 ${
                        passwordsMatch ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      {passwordsMatch
                        ? "Passwords match ✅"
                        : "Passwords do not match ❌"}
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={loading || !passwordsMatch}
                  className={`w-full py-3 rounded-lg font-semibold text-white transition-colors ${
                    passwordsMatch
                      ? "bg-gradient-to-r from-purple-500 to-purple-600"
                      : "bg-gradient-to-r from-purple-400 to-purple-300"
                  } ${
                    loading
                      ? "opacity-70 cursor-not-allowed"
                      : "hover:opacity-90"
                  }`}
                >
                  {loading ? "Resetting..." : "Reset Password"}
                </button>
              </form>
            </>
          ) : (
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-3xl text-green-600">✓</span>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Password Reset!
              </h2>
              <p className="text-gray-600 mb-6">
                Your password has been reset successfully.
              </p>
              <Link
                to="/login"
                className="inline-block w-full bg-gradient-to-r from-purple-400 to-purple-300 text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
              >
                Go to Login
              </Link>
            </div>
          )}

          <div className="mt-8 text-center">
            <Link
              to="/verify-otp"
              className="text-gray-500 hover:text-gray-700 text-sm inline-flex items-center"
            >
              ← Back to Verification
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
