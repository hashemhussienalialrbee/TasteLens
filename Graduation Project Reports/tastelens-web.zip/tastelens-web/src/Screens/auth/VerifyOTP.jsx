import React, { useState, useRef, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { api } from "../../Auth/api";
import { toast } from "react-toastify";

const VerifyOTP = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const email = location.state?.email;
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(30);
  const inputRefs = useRef([]);

  if (!email) navigate("/forgot-password");

  const handleChange = (index, value) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    if (value && index < 3) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0)
      inputRefs.current[index - 1]?.focus();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const otpCode = otp.join("");
    if (otpCode.length !== 4) return toast.error("Enter a 4-digit OTP");

    setLoading(true);
    try {
      const { data } = await api.post("/accounts/verify-otp", {
        email,
        otp: otpCode,
      });

      if (data.token_id) {
        toast.success("OTP Verified Successfully!");
        navigate("/reset-password", { state: { token_id: data.token_id } });
      } else {
        toast.error(data.message || "Invalid OTP");
      }
    } catch (err) {
      toast.error(err.response?.data?.message || "Verification failed");
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    setResendCooldown(30);
    try {
      const { data } = await api.post(
        "/accounts/re-send-otp",
        { email },
        { withCredentials: true }
      );
      toast.success(data.message || "OTP resent successfully!");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to resend OTP");
    }
  };

  useEffect(() => {
    if (resendCooldown === 0) return;
    const timer = setInterval(
      () => setResendCooldown((prev) => prev - 1),
      1000
    );
    return () => clearInterval(timer);
  }, [resendCooldown]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-purple-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8 md:p-12">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full mx-auto mb-4 flex items-center justify-center">
            <span className="text-2xl text-white">✉️</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">TasteLens</h1>
        </div>

        <h2 className="text-3xl font-bold mb-2 text-gray-900">Verify Code</h2>
        <p className="text-gray-600 mb-8">
          Enter the 4-digit code sent to <br />
          <span className="font-semibold text-purple-600">{email}</span>
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-center space-x-3">
            {otp.map((digit, i) => (
              <input
                key={i}
                type="text"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(i, e.target.value)}
                onKeyDown={(e) => handleKeyDown(i, e)}
                ref={(el) => (inputRefs.current[i] = el)}
                className="w-16 h-16 text-center text-2xl font-bold border-2 border-gray-300 rounded-lg focus:border-purple-400 focus:outline-none transition-colors"
                disabled={loading}
              />
            ))}
          </div>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 rounded-lg font-semibold text-white transition-colors 
    ${
      otp.some((d) => d.trim() !== "")
        ? "bg-gradient-to-r from-purple-500 to-purple-600"
        : "bg-gradient-to-r from-purple-400 to-purple-300"
    } 
    ${loading ? "opacity-70 cursor-not-allowed" : "hover:opacity-90"}
  `}
          >
            {loading ? "Verifying..." : "Verify Code"}
          </button>
        </form>

        <p className="text-center text-gray-600 mt-6">
          Didn't receive the code?{" "}
          {resendCooldown > 0 ? (
            <span className="text-gray-400">Resend in {resendCooldown}s</span>
          ) : (
            <button
              onClick={handleResendCode}
              className="text-purple-500 hover:underline font-semibold"
            >
              Resend Code
            </button>
          )}
        </p>

        <div className="mt-8 text-center">
          <Link
            to="/forgot-password"
            className="text-gray-500 hover:text-gray-700 text-sm inline-flex items-center"
          >
            ← Back to Email
          </Link>
        </div>
      </div>
    </div>
  );
};

export default VerifyOTP;
