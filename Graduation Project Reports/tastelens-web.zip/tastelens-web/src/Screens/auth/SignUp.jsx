import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../../Auth/api";
import { toast } from "react-toastify";
import FormInput from "../../components/FormInput";
import PasswordInput from "../../components/PasswordInput";

const initialForm = {
  first_name: "",
  last_name: "",
  email: "",
  phone_number: "",
  password: "",
  confirmPassword: "",
};

const Signup = () => {
  const [formData, setFormData] = useState(initialForm);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const passwordsMatch =
    formData.password && formData.password === formData.confirmPassword;

  const allFieldsFilled = Object.values(formData).every(
    (value) => value.trim() !== ""
  );

  const canSubmit = allFieldsFilled && passwordsMatch && !loading;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!canSubmit) return;

    setLoading(true);

    try {
      await api.post("/users/", {
        first_name: formData.first_name,
        last_name: formData.last_name,
        email: formData.email,
        phone_number: formData.phone_number,
        password: formData.password,
        account_type: "user",
      });

      toast.success("Account created successfully!");
      navigate("/login");
    } catch (err) {
      toast.error(err.response?.data?.message || "Signup failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl overflow-hidden shadow-2xl max-w-4xl w-full grid md:grid-cols-2">
        {/* Left */}
        <div className="p-8 md:p-12 flex flex-col justify-center">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-2xl text-white">🍴</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">TasteLens</h1>
          </div>

          <h2 className="text-3xl font-bold mb-6 text-gray-900">
            Create Your Account
          </h2>

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormInput
                label="First Name"
                name="first_name"
                value={formData.first_name}
                onChange={handleChange}
              />
              <FormInput
                label="Last Name"
                name="last_name"
                value={formData.last_name}
                onChange={handleChange}
              />
            </div>

            <FormInput
              label="Email"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />

            <FormInput
              label="Phone Number"
              name="phone_number"
              value={formData.phone_number}
              onChange={handleChange}
            />

            <PasswordInput
              label="Password"
              name="password"
              value={formData.password}
              onChange={handleChange}
            />

            <PasswordInput
              label="Confirm Password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
            />

            {formData.confirmPassword && (
              <p
                className={`text-sm ${
                  passwordsMatch ? "text-green-600" : "text-red-600"
                }`}
              >
                {passwordsMatch
                  ? "Passwords match ✅"
                  : "Passwords do not match ❌"}
              </p>
            )}

            <div className="flex items-center">
              {" "}
              <input
                type="checkbox"
                required
                className="w-4 h-4 text-purple-500"
              />{" "}
              <span className="ml-2 text-sm text-gray-600">
                {" "}
                I agree to the{" "}
                <span className="text-purple-500 hover:underline">
                  Terms
                </span>{" "}
                and{" "}
                <span className="text-purple-500 hover:underline">
                  {" "}
                  Privacy Policy{" "}
                </span>{" "}
              </span>{" "}
            </div>

            <button
              disabled={!canSubmit}
              className={`
                w-full text-white py-3 rounded-lg font-semibold transition-all
                bg-gradient-to-r 
                ${
                  canSubmit
                    ? "from-purple-500 to-purple-600"
                    : "from-purple-300 to-purple-300"
                }
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
            >
              {loading ? "Creating..." : "Create Account"}
            </button>
          </form>

          <p className="text-center text-gray-600 mt-6">
            Already have an account?{" "}
            <Link to="/login" className="text-purple-500 hover:underline">
              Log in
            </Link>
          </p>
        </div>

        {/* Image */}
        <div className="hidden md:block">
          <img
            src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&h=1000&fit=crop"
            className="w-full h-full object-cover"
            alt="Food"
          />
        </div>
      </div>
    </div>
  );
};

export default Signup;
