import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../../Auth/api";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data } = await api.post("/accounts/forgot-password", { email });

      toast.success(data.message || "Verification code sent!");

      navigate("/verify-otp", { state: { email } });
    } catch (err) {
      const errorMessage =
        err.response?.data?.message ||
        "Failed to send verification code. Try again.";

      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-purple-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full">
        <div className="p-8 md:p-12">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-2xl text-white">🔒</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">TasteLens</h1>
          </div>

          {!isSubmitted ? (
            <>
              <h2 className="text-3xl font-bold mb-2 text-gray-900">
                Reset Password
              </h2>
              <p className="text-gray-600 mb-8">
                Enter your email address and we'll send you a verification code.
              </p>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-purple-400 transition-colors"
                    required
                    disabled={loading}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={`w-full py-3 rounded-lg font-semibold text-white transition-colors 
    ${
      email.trim()
        ? "bg-gradient-to-r from-purple-500 to-purple-600"
        : "bg-gradient-to-r from-purple-400 to-purple-300"
    } 
    ${loading ? "opacity-70 cursor-not-allowed" : "hover:opacity-90"}
  `}
                >
                  {loading ? "Sending..." : "Send Verification Code"}
                </button>
              </form>
            </>
          ) : (
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-3xl text-green-600">✓</span>
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Check Your Email
              </h2>
              <p className="text-gray-600 mb-6">
                We've sent a 4-digit verification code to <br />
                <span className="font-semibold text-purple-600">{email}</span>
              </p>

              <Link
                to="/verify-otp"
                className="inline-block w-full bg-gradient-to-r from-purple-400 to-purple-300 text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
              >
                Continue to Verify Code
              </Link>
            </div>
          )}

          <div className="mt-8 text-center">
            <Link
              to="/login"
              className="text-gray-500 hover:text-gray-700 text-sm inline-flex items-center"
            >
              ← Back to Login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
