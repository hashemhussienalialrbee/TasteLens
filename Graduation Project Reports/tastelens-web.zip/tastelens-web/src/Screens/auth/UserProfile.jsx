import React, { useEffect, useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import { api } from "../../Auth/api";
import { toast } from "react-toastify";
import { AuthContext } from "../../Auth/authProvider";
import { FaUser, FaEnvelope, FaPhone, FaArrowLeft } from "react-icons/fa";

const UserProfile = () => {
  const navigate = useNavigate();
  const { updateUser } = useContext(AuthContext);

  const [user, setUser] = useState(null);
  const [form, setForm] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone_number: "",
  });

  const [saving, setSaving] = useState(false);

  const getAccountId = () => {
    const userCookie = Cookies.get("user");
    if (!userCookie) return null;
    try {
      return JSON.parse(decodeURIComponent(userCookie)).id;
    } catch {
      return JSON.parse(userCookie).id;
    }
  };

  const accountId = getAccountId();

  const formatDate = (date) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  useEffect(() => {
    if (!accountId) {
      navigate("/login");
      return;
    }

    const loadProfile = async () => {
      try {
        const { data } = await api.get(`/accounts/${accountId}`);
        if (data) {
          setUser(data);
          setForm({
            first_name: data.first_name || "",
            last_name: data.last_name || "",
            email: data.email || "",
            phone_number: data.phone_number || "",
          });
        }
      } catch (error) {
        toast.error("Failed to load profile");
      }
    };

    loadProfile();
  }, [accountId, navigate]);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSave = async () => {
    if (!accountId) return;

    setSaving(true);
    try {
      const { data } = await api.patch(`/accounts/${accountId}`, form);

      setUser(data);
      updateUser(data);

      Cookies.set("user", encodeURIComponent(JSON.stringify(data)), {
        expires: 7,
      });
      Cookies.set("user_name", data.first_name, { expires: 7 });

      toast.success("Profile updated!");
    } catch (error) {
      toast.error("Update failed");
    } finally {
      setSaving(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-3 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 px-4">
      <div className="max-w-2xl mx-auto">
        <button onClick={() => navigate(-1)} className="mb-6 text-gray-600">
          <FaArrowLeft className="inline mr-2" /> Back
        </button>

        <div className="bg-white rounded-xl shadow p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
                <FaUser className="w-8 h-8 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {user.first_name} {user.last_name}
                </h1>
                <p className="text-gray-600">{user.email}</p>
              </div>
            </div>

            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Edit Profile
            </h2>
          </div>

          {/* Form */}
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  First Name
                </label>
                <input
                  name="first_name"
                  value={form.first_name}
                  onChange={handleChange}
                  className="w-full p-3 border rounded-lg"
                  disabled={saving}
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-2">
                  Last Name
                </label>
                <input
                  name="last_name"
                  value={form.last_name}
                  onChange={handleChange}
                  className="w-full p-3 border rounded-lg"
                  disabled={saving}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-2">Email</label>
              <div className="relative">
                <FaEnvelope className="absolute left-3 top-3 text-gray-400" />
                <input
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  className="w-full pl-10 p-3 border rounded-lg"
                  disabled={saving}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-700 mb-2">Phone</label>
              <div className="relative">
                <FaPhone className="absolute left-3 top-3 text-gray-400" />
                <input
                  name="phone_number"
                  value={form.phone_number}
                  onChange={handleChange}
                  className="w-full pl-10 p-3 border rounded-lg"
                  disabled={saving}
                />
              </div>
            </div>
          </div>

          {/* Account Info Component */}
          <div className="mt-8 pt-6 border-t">
            <div className="grid grid-cols-2 gap-4">
              {/* Created At */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Created At</p>
                <p className="font-medium text-gray-900">
                  {formatDate(user.created_at)}
                </p>
              </div>

              <div
                className={`p-4 rounded-lg ${
                  user.is_deleted ? "bg-red-50" : "bg-green-50"
                }`}
              >
                <p className="text-sm text-gray-500 mb-1">Status</p>
                <p
                  className={`font-medium ${
                    user.is_deleted ? "text-red-600" : "text-green-600"
                  }`}
                >
                  {user.is_deleted ? "Inactive" : "Active"}
                </p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 mt-8 pt-6 border-t">
            <button
              onClick={() => navigate("/home")}
              className="px-5 py-2.5 text-gray-700 border rounded-lg"
              disabled={saving}
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-5 py-2.5 bg-purple-600 text-white rounded-lg"
            >
              {saving ? "Saving..." : "Save"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
