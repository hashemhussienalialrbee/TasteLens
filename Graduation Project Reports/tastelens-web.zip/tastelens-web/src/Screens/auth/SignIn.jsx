import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import { AuthContext } from "../../Auth/authProvider";
import { api } from "../../Auth/api";

import FormInput from "../../components/FormInput";
import PasswordInput from "../../components/PasswordInput";

const Login = () => {
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const isReady = email && password;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isReady) return;

    setLoading(true);

    try {
      const { data } = await api.post("/accounts/login", {
        email,
        password,
      });

      const { access_token, account } = data;

      login(account, access_token, account.account_type);

      toast.success(`Welcome back, ${account.first_name || account.email}!`);

      navigate(account.account_type === "admin" ? "/admin/dashboard" : "/home");
    } catch (err) {
      toast.error("Login failed. Please check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl overflow-hidden shadow-2xl max-w-4xl w-full grid md:grid-cols-2">
        {/* Left Image */}
        <div className="hidden md:block">
          <img
            src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&h=1000&fit=crop"
            alt="Food"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Right Content */}
        <div className="p-8 md:p-12 flex flex-col justify-center">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-2xl text-white">🍴</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">TasteLens</h1>
            <p className="text-sm text-gray-600">
              Mood-based restaurant discovery
            </p>
          </div>

          <h2 className="text-3xl font-bold mb-6 text-gray-900">Log in</h2>

          <form className="space-y-6" onSubmit={handleSubmit}>
            <FormInput
              label="Email Address"
              type="email"
              placeholder="email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
            />

            <PasswordInput
              label="Password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
            />

            <div className="flex justify-between items-center">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  className="w-4 h-4 text-purple-500 rounded"
                />
                <span className="ml-2 text-sm text-gray-600">Remember me</span>
              </label>

              <Link
                to="/forgot-password"
                className="text-purple-500 font-semibold text-sm hover:underline"
              >
                Forget Password?
              </Link>
            </div>

            <button
              type="submit"
              disabled={!isReady || loading}
              className={`
                w-full py-3 rounded-lg font-semibold text-white
                bg-gradient-to-r from-purple-400 to-purple-300
                transition-opacity
                ${isReady ? "from-purple-500 to-purple-600" : ""}
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
            >
              {loading ? "Logging in..." : "Log in"}
            </button>
          </form>

          <p className="text-center text-gray-600 mt-6">
            Don't have an account?{" "}
            <Link
              to="/signup"
              className="text-purple-500 font-semibold hover:underline"
            >
              Sign up
            </Link>
          </p>

          <div className="mt-6 text-center">
            <Link to="/" className="text-gray-500 hover:text-gray-700 text-sm">
              ← Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
