import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import activities from "../data/Activities";
import {
  FaStar,
  FaMapMarkerAlt,
  FaClock,
  FaTag,
  FaFilter,
  FaArrowRight,
} from "react-icons/fa";

const Activities = () => {
  const navigate = useNavigate();
  const [filteredCategory, setFilteredCategory] = useState("All");

  const categories = [
    "All",
    ...new Set(activities.map((activity) => activity.category)),
  ];

  const filteredActivities =
    filteredCategory === "All"
      ? activities
      : activities.filter((activity) => activity.category === filteredCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-purple-600 hover:text-purple-800 mb-6"
          >
            <span className="text-2xl mr-2">←</span>
            Back
          </button>

          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Activities in Jordan 🇯🇴
          </h1>
          <p className="text-gray-600 text-lg">
            Discover amazing experiences across the Hashemite Kingdom
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <FaFilter className="text-purple-600" />
            <h2 className="text-xl font-semibold text-gray-900">
              Filter by Category
            </h2>
          </div>

          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setFilteredCategory(category)}
                className={`px-5 py-2.5 rounded-full transition-all ${
                  filteredCategory === category
                    ? "bg-purple-600 text-white shadow-md"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredActivities.map((activity) => (
            <div
              key={activity.id}
              className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 group"
            >
              {/* Activity Image */}
              <div className="h-56 overflow-hidden relative">
                <img
                  src={activity.image}
                  alt={activity.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4">
                  <span className="bg-white/90 backdrop-blur-sm text-gray-800 px-3 py-1.5 rounded-full text-sm font-semibold">
                    {activity.price_range}
                  </span>
                </div>
              </div>

              {/* Activity Content */}
              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-bold text-gray-900 line-clamp-1">
                    {activity.name}
                  </h3>
                  <div className="flex items-center bg-amber-50 text-amber-700 px-2 py-1 rounded">
                    <FaStar className="mr-1" />
                    <span className="font-bold">{activity.rating}</span>
                  </div>
                </div>

                <p className="text-gray-600 mb-4 line-clamp-2">
                  {activity.description}
                </p>

                {/* Location & Duration */}
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <FaMapMarkerAlt className="mr-2" />
                  <span className="mr-4">{activity.location}</span>
                  <FaClock className="mr-2" />
                  <span>{activity.duration}</span>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {activity.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center gap-1 bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                    >
                      <FaTag className="text-xs" />
                      {tag}
                    </span>
                  ))}
                  {activity.tags.length > 3 && (
                    <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                      +{activity.tags.length - 3}
                    </span>
                  )}
                </div>

                {/* Category & Difficulty & View Details Button */}
                <div className="flex justify-between items-center pt-4 border-t">
                  <div className="flex items-center gap-3">
                    <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
                      {activity.category}
                    </span>
                    <span className="text-sm text-gray-600">
                      {activity.difficulty}
                    </span>
                  </div>

                  {/* زر View Details */}
                  <button
                    onClick={() => navigate(`/activities/${activity.id}`)}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:opacity-90 transition-all text-sm font-medium"
                  >
                    <span>View Details</span>
                    <FaArrowRight className="text-xs" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="mt-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-8 text-white">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-2">Explore Jordan's Beauty</h2>
            <p className="text-white/90 mb-6">
              {activities.length} unique activities across{" "}
              {new Set(activities.map((a) => a.location.split(", ")[1])).size}{" "}
              governorates
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <p className="text-3xl font-bold">{activities.length}</p>
                <p className="text-sm text-white/80">Activities</p>
              </div>
              <div>
                <p className="text-3xl font-bold">
                  {new Set(activities.map((a) => a.category)).size}
                </p>
                <p className="text-sm text-white/80">Categories</p>
              </div>
              <div>
                <p className="text-3xl font-bold">4.8</p>
                <p className="text-sm text-white/80">Avg Rating</p>
              </div>
              <div>
                <p className="text-3xl font-bold">
                  {activities.filter((a) => a.rating >= 4.8).length}
                </p>
                <p className="text-sm text-white/80">Top Rated</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Activities;
