import React, { useState, useContext } from "react";
import { AuthContext } from "../Auth/authProvider";
import { api } from "../Auth/api";
import { toast } from "react-toastify";

const Contact = () => {
  const { user } = useContext(AuthContext);

  const [formData, setFormData] = useState({
    message: "",
    type: "general",
  });

  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleTypeChange = (type) => {
    setFormData({
      ...formData,
      type: type,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.message.trim()) {
      toast.error("Please enter a message");
      return;
    }

    setLoading(true);

    try {
      await api.post("/contact-us", {
        message: formData.message,
        type: formData.type,
      });

      toast.success("Message sent!");
      setSubmitted(true);

      // Reset the form after 3 seconds
      setTimeout(() => {
        setSubmitted(false);
        setFormData({ message: "", type: "general" });
      }, 3000);
    } catch (error) {
      console.log("Contact error:", error);
      toast.error("Failed to send message");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-50 py-12">
      <div className="max-w-2xl mx-auto px-4">
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="text-3xl text-white">📧</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Contact Us</h1>
          <p className="text-gray-600 text-lg">Send us a message</p>
        </div>

        {/* Contact Form */}
        <div className="bg-white rounded-3xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Contact Form
          </h2>

          {submitted ? (
            <div className="bg-green-50 border border-green-200 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-green-600 text-3xl">✓</span>
              </div>
              <h3 className="text-2xl font-bold text-green-700 mb-2">
                Message Sent Successfully!
              </h3>
              <p className="text-green-600">
                Thank you for contacting us. We'll get back to you soon.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Message Type */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Message Type
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => handleTypeChange("general")}
                    className={`py-3 rounded-lg font-medium transition-colors ${
                      formData.type === "general"
                        ? "bg-gradient-to-r from-purple-500 to-purple-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    General
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTypeChange("support")}
                    className={`py-3 rounded-lg font-medium transition-colors ${
                      formData.type === "support"
                        ? "bg-gradient-to-r from-purple-500 to-purple-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Support
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTypeChange("technical")}
                    className={`py-3 rounded-lg font-medium transition-colors ${
                      formData.type === "technical"
                        ? "bg-gradient-to-r from-purple-500 to-purple-600 text-white"
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    Technical
                  </button>
                </div>
              </div>

              {/* Message Textarea */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Your Message
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={(e) =>
                    setFormData({ ...formData, message: e.target.value })
                  }
                  rows="8"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-purple-400 transition-colors"
                  placeholder="Type your message here..."
                  required
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={loading}
                className={`w-full py-3 rounded-lg font-semibold text-lg transition-colors ${
                  formData.message.trim()
                    ? "bg-gradient-to-r from-purple-500 to-purple-600 text-white"
                    : "bg-gradient-to-r from-purple-400 to-purple-300 text-white"
                } ${
                  loading ? "opacity-70 cursor-not-allowed" : "hover:opacity-90"
                }`}
              >
                {loading ? "Sending..." : "Send Message"}
              </button>

              <div className="text-center text-gray-500 text-sm pt-4 border-t border-gray-100">
                <p>We'll respond to your message as soon as possible.</p>
              </div>
            </form>
          )}
        </div>

        <div className="text-center mt-8 text-gray-600">
          <p>Need immediate help? Check our FAQ section.</p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
