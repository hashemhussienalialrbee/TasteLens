export const restaurants = [
  {
    id: 1,
    name: "Ward Restaurant",
    type: "Food • $$",
    rating: 4.8,
    imageColor: "bg-gradient-to-r from-yellow-400 to-orange-500",
    imageUrl:
      "https://lh3.googleusercontent.com/gps-cs-s/AG0ilSyYOxNBbG6ivGwEhZ1JySY-U4iudS95Pvxq8-wUWm1kiQtWbtOe7HScupkt65v2OFHOPRXQuN1skhf4_UtdeD8Mdw68wPqEZq8B19Kysyqe0LFZee775IadhLXzo42WaCIkkfqvKg=s680-w680-h510-rw",
  },
  {
    id: 2,
    name: "Calma Space Cafe",
    type: "Coffee • Study • $",
    rating: 4.7,
    imageColor: "bg-gradient-to-r from-brown-400 to-amber-700",
    imageUrl:
      "https://images.unsplash.com/photo-1493857671505-72967e2e2760?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
  {
    id: 3,
    name: "Crepello",
    type: "Desert • $$$",
    rating: 4.6,
    imageColor: "bg-gradient-to-r from-blue-400 to-cyan-500",
    imageUrl:
      "https://images.unsplash.com/photo-1583410629430-f6e1cc550e97?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
  {
    id: 4,
    name: "Camel",
    type: "Fast Food • $$",
    rating: 4.3,
    imageColor: "bg-gradient-to-r from-red-400 to-yellow-500",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2fvjgregPIG3u78H34J7tJhwgvGdlQn-7VQ&s",
  },
];

export const landingHero = {
  title: "Taste",
  subtitle: "Discover & Savor extraordinary culinary journeys",
  description:
    "Where every mood finds its perfect flavor. Explore handpicked restaurants, cafes, and hidden gems tailored to your taste.",
  backgroundImage:
    "https://images.unsplash.com/photo-1559314809-2b99056a8c4a?q=80&w=2070&auto=format&fit=crop",
  gradientCircles: [
    {
      top: "20",
      right: "20",
      w: "64",
      h: "64",
      from: "purple-300",
      to: "pink-300",
      animation: "pulse",
      opacity: "20",
    },
    {
      bottom: "-20",
      left: "-20",
      w: "96",
      h: "96",
      from: "orange-200",
      to: "yellow-200",
      animation: "pulse",
      opacity: "20",
    },
    {
      top: "1/2",
      left: "1/3",
      w: "48",
      h: "48",
      from: "blue-300",
      to: "cyan-300",
      animation: "bounce",
      opacity: "15",
    },
  ],
};

export const landingStats = [
  {
    number: "1,00+",
    label: "Restaurants",
    color: "from-purple-500 to-purple-600",
  },
  { number: "15+", label: "Cities", color: "from-pink-500 to-pink-600" },
  { number: "5K+", label: "Foodies", color: "from-orange-500 to-orange-600" },
  { number: "4.9★", label: "Avg Rating", color: "from-blue-500 to-blue-600" },
];

export const landingSteps = [
  {
    step: "01",
    title: "Share Your Mood",
    description: "Tell us what you're craving or how you feel",
    icon: "🎯",
    color: "from-purple-500 to-purple-600",
  },
  {
    step: "02",
    title: "Get Smart Recommendations",
    description: "AI-powered suggestions tailored just for you",
    icon: "🤖",
    color: "from-pink-500 to-pink-600",
  },
  {
    step: "03",
    title: "Savor the Experience",
    description: "Discover, book, and enjoy unforgettable moments",
    icon: "🌟",
    color: "from-orange-500 to-orange-600",
  },
];
