import {
  FaUsers,
  FaEnvelope,
  FaUtensils,
  FaChartLine,
  FaStar,
  FaCalendarAlt,
} from "react-icons/fa";

export const statCards = [
  {
    key: "totalUsers",
    label: "Total Users",
    icon: FaUsers,
    color: "from-purple-500 to-purple-600",
  },
  {
    key: "newMessages",
    label: "New Messages",
    icon: FaEnvelope,
    color: "from-pink-500 to-rose-500",
  },
  {
    key: "totalRestaurants",
    label: "Restaurants",
    icon: FaUtensils,
    color: "from-amber-500 to-orange-500",
  },
  {
    key: "activeToday",
    label: "Active Today",
    icon: FaChartLine,
    color: "from-blue-500 to-cyan-500",
  },
  {
    key: "satisfactionRate",
    label: "Satisfaction Rate",
    icon: FaStar,
    color: "from-emerald-500 to-green-500",
  },
  {
    key: "monthlyGrowth",
    label: "Monthly Growth",
    icon: FaCalendarAlt,
    color: "from-indigo-500 to-purple-500",
  },
];

export const activity = [
  { text: "New user registered", time: "10 min ago", icon: "👤" },
  { text: "Contact message received", time: "25 min ago", icon: "📧" },
  { text: "New restaurant added", time: "1 hour ago", icon: "🍽️" },
  { text: "Backup completed", time: "2 hours ago", icon: "🛡️" },
];
