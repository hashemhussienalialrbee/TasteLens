const moods = [
  {
    id: 1,
    name: "Coffee",
    icon: "☕",
    color: "bg-gradient-to-r from-amber-300 to-amber-200",
  },

  {
    id: 2,
    name: "Drinks",
    icon: "🍹",
    color: "bg-gradient-to-r from-blue-400 to-blue-300",
  },
  {
    id: 3,
    name: "Happy",
    icon: "😊",
    color: "bg-gradient-to-r from-yellow-300 to-yellow-200",
  },
  {
    id: 4,
    name: "Sad",
    icon: "😔",
    color: "bg-gradient-to-r from-gray-300 to-gray-200",
  },
  {
    id: 5,
    name: "Family",
    icon: "👨‍👩‍👧‍👦",
    color: "bg-gradient-to-r from-green-400 to-green-300",
  },
  {
    id: 6,
    name: "Romantic",
    icon: "💑",
    color: "bg-gradient-to-r from-pink-400 to-pink-300",
  },
];

export default moods;
