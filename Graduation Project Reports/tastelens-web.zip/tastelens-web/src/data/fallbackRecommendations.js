export const getFallbackRecommendations = (city) => [
  {
    id: 1,
    name: "Cafe Strada",
    description:
      "Cozy cafe with great coffee and relaxing atmosphere perfect for unwinding after a long day",
    type: "cafe",
    budget: "medium",
    location: `${city}, Jordan`,
    reason:
      "Perfect for your mood with comfortable seating, ambient music, and great coffee selection",
  },
  {
    id: 2,
    name: "Wild Jordan Center",
    description:
      "Nature center with breathtaking views, local crafts, and sustainable tourism experiences",
    type: "nature",
    budget: "low",
    location: `${city}, Jordan`,
    reason:
      "Matches your preference for peaceful environments and connection with nature",
  },
  {
    id: 3,
    name: "Abdali Mall",
    description:
      "Modern shopping destination with premium brands, dining options, and entertainment facilities",
    type: "shopping",
    budget: "high",
    location: `${city}, Jordan`,
    reason:
      "Great for socializing, entertainment, and premium shopping experience",
  },
];
