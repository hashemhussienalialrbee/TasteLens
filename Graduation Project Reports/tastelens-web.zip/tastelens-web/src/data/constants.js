export const dummyImages = [
  "https://images.unsplash.com/photo-1513584684374-8bab748fbf90?w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1514933651103-005eec06c04b?w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1559329007-40df8a9345d8?w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1516738901171-8eb4fc13bd20?w=800&auto=format&fit=crop",
];

export const DUMMY_IMAGES = dummyImages;

export const CITIES = [
  "Amman",
  "Irbid",
  "Aqaba",
  "Petra",
  "Dead Sea",
  "Jarash",
];

export const AGES = [18, 25, 35, 50];
export const BUDGETS = ["low", "medium", "high"];
export const RELATIONSHIPS = ["single", "in_a_relationship", "married"];

export const STEPS = [
  { id: 1, title: "Select Mood", icon: "FaSmile" },
  { id: 2, title: "Your Details", icon: "FaUser" },
  { id: 3, title: "AI Results", icon: "FaSearch" },
];

export const HOW_IT_WORKS = [
  {
    icon: "😊",
    title: "Choose Your Mood",
    desc: "Select how you're feeling right now",
  },
  {
    icon: "📝",
    title: "Share Details",
    desc: "Tell us about your preferences",
  },
  {
    icon: "✨",
    title: "Get AI Magic",
    desc: "Receive personalized recommendations",
  },
];
