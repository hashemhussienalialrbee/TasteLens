import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../Auth/authProvider";
import logo from "../assets/logo.png";

const navLinks = [
  { to: "/activities", label: "Activities" },
  { to: "/places", label: "Places" },
  { to: "/about-us", label: "About Us" },
  { to: "/contact-us", label: "Contact Us" },
];

const NavLinkList = ({ links, onClick }) => (
  <>
    {links.map((link) => (
      <Link
        key={link.to}
        to={link.to}
        onClick={onClick}
        className="text-gray-700 hover:text-purple-500 font-medium block md:inline-block py-2 md:py-0"
      >
        {link.label}
      </Link>
    ))}
  </>
);

const Header = () => {
  const { user, isAuthenticated, logout, first_name } = useContext(AuthContext);
  const navigate = useNavigate();

  const [openMobile, setOpenMobile] = useState(false);
  const [openUserMenu, setOpenUserMenu] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
    setOpenMobile(false);
    setOpenUserMenu(false);
  };

  const homeLink = isAuthenticated ? "/home" : "/";

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link to={homeLink} className="flex items-center gap-3">
          {/* Logo Container */}
          <div className="relative">
            <img
              src={logo}
              alt="TasteLens Logo"
              className="w-10 h-10 md:w-12 md:h-12"
            />
            <div className="absolute -inset-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full blur opacity-20"></div>
          </div>

          {/* Text */}
          <div>
            <h1 className="text-xl md:text-2xl font-bold text-gray-900">
              Taste
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Lens
              </span>
            </h1>
            <div className="hidden md:block text-xs text-gray-500">
              Your food journey guide
            </div>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link
            to={homeLink}
            className="text-gray-700 hover:text-purple-500 font-medium"
          >
            Home
          </Link>

          {isAuthenticated && <NavLinkList links={navLinks} />}

          {isAuthenticated ? (
            <div className="relative">
              <button
                onClick={() => setOpenUserMenu(!openUserMenu)}
                className="flex items-center space-x-3 hover:opacity-80"
              >
                <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full flex items-center justify-center">
                  <span className="text-xl">{user?.first_name?.charAt(0)}</span>
                </div>
                <span className="font-semibold">
                  {user?.first_name || user?.email}
                </span>
              </button>

              {openUserMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border py-1">
                  <Link
                    to="/user-profile"
                    className="block px-4 py-3 hover:bg-gray-100"
                  >
                    👤 Profile
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-3 text-red-600 hover:bg-red-50"
                  >
                    🚪 Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" className="hover:text-purple-500">
              Login
            </Link>
          )}
        </nav>

        {/* Mobile Button */}
        <button
          onClick={() => setOpenMobile(!openMobile)}
          className="md:hidden text-2xl"
        >
          {openMobile ? "✕" : "☰"}
        </button>
      </div>

      {/* Mobile Menu */}
      {openMobile && (
        <div className="md:hidden mt-4 border-t pt-4 px-4 space-y-3">
          <Link
            to={homeLink}
            onClick={() => setOpenMobile(false)}
            className="block py-2 hover:text-purple-500"
          >
            Home
          </Link>

          {isAuthenticated && (
            <NavLinkList
              links={navLinks}
              onClick={() => setOpenMobile(false)}
            />
          )}

          <div className="border-t pt-3">
            {isAuthenticated ? (
              <>
                <Link
                  to="/user-profile"
                  onClick={() => setOpenMobile(false)}
                  className="block py-2 hover:text-purple-500"
                >
                  👤 Profile
                </Link>
                <button
                  onClick={handleLogout}
                  className="w-full text-left text-red-600 py-2 hover:text-red-700"
                >
                  🚪 Logout
                </button>
              </>
            ) : (
              <Link
                to="/login"
                onClick={() => setOpenMobile(false)}
                className="block py-2 hover:text-purple-500"
              >
                Login
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
