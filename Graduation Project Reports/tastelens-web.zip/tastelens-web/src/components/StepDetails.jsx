import React from "react";
import {
  FaUserFriends,
  FaUser,
  FaMoneyBillWave,
  FaMapMarkerAlt,
  FaHeart,
  FaGlobeAmericas,
  FaArrowRight,
  FaSpinner,
} from "react-icons/fa";
import { AGES, BUDGETS, CITIES, RELATIONSHIPS } from "../data/constants";

const StepDetails = ({
  userDetails,
  selectedMood,
  onChange,
  onNext,
  isLoading,
  onBack,
}) => (
  <div className="max-w-4xl mx-auto">
    <div className="text-center mb-10">
      <div className="inline-flex items-center gap-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-8 py-4 rounded-full mb-6 shadow-lg shadow-emerald-200">
        <FaUserFriends className="text-xl" />
        <span className="font-bold text-lg tracking-wide">
          Step 2: Personalize Your Experience
        </span>
      </div>

      <div className="flex items-center justify-center mb-4">
        <div className="text-4xl mr-4 animate-bounce">{selectedMood?.icon}</div>
        <h2 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600">
          Tell us about yourself
        </h2>
      </div>
      <p className="text-gray-600 text-lg max-w-2xl mx-auto">
        Help our AI understand your preferences for better recommendations
      </p>
    </div>

    <div className="bg-gradient-to-br from-white to-emerald-50 rounded-3xl shadow-2xl p-10 border border-emerald-100">
      <div className="grid md:grid-cols-2 gap-10">
        {/* Age Input */}
        <div className="space-y-4">
          <label className="text-xl font-bold text-gray-900 flex items-center gap-3">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl shadow-md">
              <FaUser className="text-white" />
            </div>
            <span>Your Age</span>
          </label>
          <div className="relative group">
            <input
              type="number"
              min="1"
              max="120"
              value={userDetails.age}
              onChange={(e) => onChange("age", e.target.value)}
              className="w-full px-6 py-5 border-2 border-gray-200 rounded-2xl focus:ring-4 focus:ring-purple-300 focus:border-transparent text-lg font-medium transition-all duration-300 group-hover:border-purple-300"
              placeholder="Enter your age"
            />
            <div className="absolute right-6 top-1/2 transform -translate-y-1/2 text-gray-400 group-hover:text-purple-500 transition-colors">
              years
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            {AGES.map((age) => (
              <button
                key={age}
                onClick={() => onChange("age", age)}
                className={`px-4 py-2 rounded-xl font-medium transition-all transform hover:scale-105 ${
                  parseInt(userDetails.age) === age
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {age}
              </button>
            ))}
          </div>
        </div>

        {/* Budget */}
        <div className="space-y-4">
          <label className="block text-xl font-bold text-gray-900 flex items-center gap-3">
            <div className="p-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl shadow-md">
              <FaMoneyBillWave className="text-white" />
            </div>
            <span>Your Budget</span>
          </label>
          <div className="grid grid-cols-3 gap-4">
            {BUDGETS.map((budget) => (
              <button
                key={budget}
                onClick={() => onChange("budget", budget)}
                className={`py-5 rounded-2xl text-lg font-bold capitalize transition-all transform hover:scale-105 hover:-translate-y-1 ${
                  userDetails.budget === budget
                    ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-xl scale-105"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200 shadow-md"
                }`}
              >
                {budget}
              </button>
            ))}
          </div>
        </div>

        {/* City */}
        <div className="space-y-4">
          <label className="block text-xl font-bold text-gray-900 flex items-center gap-3">
            <div className="p-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl shadow-md">
              <FaMapMarkerAlt className="text-white" />
            </div>
            <span>Your City</span>
          </label>
          <div className="relative group">
            <input
              type="text"
              value={userDetails.city}
              onChange={(e) => onChange("city", e.target.value)}
              className="w-full px-6 py-5 border-2 border-gray-200 rounded-2xl focus:ring-4 focus:ring-blue-300 focus:border-transparent text-lg font-medium transition-all duration-300 group-hover:border-blue-300"
              placeholder="Enter city name"
            />
            <div className="absolute right-6 top-1/2 transform -translate-y-1/2 text-gray-400 group-hover:text-blue-500 transition-colors">
              <FaGlobeAmericas />
            </div>
          </div>
          <div className="flex flex-wrap gap-3 mt-4">
            {CITIES.map((city) => (
              <button
                key={city}
                onClick={() => onChange("city", city)}
                className={`px-4 py-2 rounded-xl font-medium transition-all transform hover:scale-105 ${
                  userDetails.city === city
                    ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-lg"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {city}
              </button>
            ))}
          </div>
        </div>

        {/* Relationship Status */}
        <div className="space-y-4">
          <label className="block text-xl font-bold text-gray-900 flex items-center gap-3">
            <div className="p-3 bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl shadow-md">
              <FaHeart className="text-white" />
            </div>
            <span>Relationship Status</span>
          </label>
          <div className="grid grid-cols-2 gap-4">
            {RELATIONSHIPS.map((status) => (
              <button
                key={status}
                onClick={() => onChange("relationship_status", status)}
                className={`py-5 rounded-2xl text-lg font-bold capitalize transition-all transform hover:scale-105 hover:-translate-y-1 ${
                  userDetails.relationship_status === status
                    ? "bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-xl scale-105"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200 shadow-md"
                }`}
              >
                {status.replace("_", " ")}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Summary Card */}
      <div className="mt-10 p-6 bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl border border-purple-100 shadow-inner">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-bold text-gray-900 text-lg mb-2">
              Your Selection Summary:
            </h4>
            <div className="flex flex-wrap gap-4">
              <span className="px-4 py-2 bg-white rounded-xl shadow-sm text-gray-700">
                <span className="font-bold text-purple-600">Age:</span>{" "}
                {userDetails.age}
              </span>
              <span className="px-4 py-2 bg-white rounded-xl shadow-sm text-gray-700">
                <span className="font-bold text-emerald-600">Budget:</span>{" "}
                {userDetails.budget}
              </span>
              <span className="px-4 py-2 bg-white rounded-xl shadow-sm text-gray-700">
                <span className="font-bold text-blue-600">City:</span>{" "}
                {userDetails.city}
              </span>
              <span className="px-4 py-2 bg-white rounded-xl shadow-sm text-gray-700">
                <span className="font-bold text-pink-600">Status:</span>{" "}
                {userDetails.relationship_status.replace("_", " ")}
              </span>
            </div>
          </div>
          <div className="text-4xl animate-pulse">{selectedMood?.icon}</div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between items-center mt-12 pt-8 border-t border-gray-200">
        <button
          onClick={onBack}
          className="px-8 py-4 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 rounded-2xl font-bold hover:from-gray-200 hover:to-gray-300 transition-all duration-300 shadow-md hover:shadow-lg flex items-center gap-3"
        >
          ← Back to Moods
        </button>

        <button
          onClick={onNext}
          disabled={isLoading || !userDetails.age || !userDetails.city}
          className="px-10 py-5 bg-gradient-to-r from-purple-600 via-pink-500 to-rose-500 text-white rounded-2xl font-bold hover:opacity-90 disabled:opacity-50 flex items-center gap-4 shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 disabled:hover:scale-100 disabled:hover:shadow-xl"
        >
          {isLoading ? (
            <>
              <FaSpinner className="animate-spin text-xl" />
              <span className="text-lg">AI is thinking...</span>
            </>
          ) : (
            <>
              <span className="text-lg">Generate AI Recommendations</span>
              <FaArrowRight className="text-xl" />
            </>
          )}
        </button>
      </div>
    </div>
  </div>
);

export default StepDetails;
