import React from "react";
import { STEPS } from "../data/constants";
import { FaCheckCircle, FaSmile, FaUser, FaSearch } from "react-icons/fa";

const StepsIndicator = ({ step }) => {
  const steps = STEPS.map((s) => ({
    ...s,
    icon:
      s.icon === "FaSmile" ? FaSmile : s.icon === "FaUser" ? FaUser : FaSearch,
  }));

  return (
    <div className="mb-12">
      <div className="flex justify-center items-center max-w-3xl mx-auto relative">
        {steps.map((s) => (
          <div key={s.id} className="flex flex-col items-center mx-12 relative">
            <div
              className={`w-16 h-16 rounded-full flex items-center justify-center text-white font-bold
                transition-all duration-500 transform hover:scale-110
                ${
                  step >= s.id
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg shadow-purple-200"
                    : "bg-gradient-to-r from-gray-300 to-gray-400"
                }
                ${
                  step === s.id
                    ? "ring-4 ring-purple-300 ring-opacity-50 scale-110"
                    : ""
                }
              `}
            >
              {step > s.id ? (
                <FaCheckCircle className="text-xl" />
              ) : (
                <s.icon className="text-xl" />
              )}
            </div>
            <div
              className={`mt-3 text-sm font-medium ${
                step >= s.id ? "text-purple-600 font-bold" : "text-gray-400"
              }`}
            >
              {s.title}
            </div>
            {step === s.id && (
              <div className="absolute -bottom-2 w-6 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
            )}
          </div>
        ))}
        <div className="absolute top-8 left-1/4 right-1/4 h-1 bg-gradient-to-r from-purple-100 to-pink-100 -z-10"></div>
        <div
          className="absolute top-8 left-1/4 h-1 bg-gradient-to-r from-purple-500 to-pink-500 -z-10 transition-all duration-500"
          style={{ width: `${((step - 1) / 2) * 50}%` }}
        ></div>
      </div>
    </div>
  );
};

export default StepsIndicator;
