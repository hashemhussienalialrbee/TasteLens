import React, { useContext, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AuthContext } from "../Auth/authProvider";

const SideBar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout } = useContext(AuthContext);
  const [isOpen, setIsOpen] = useState(false);

  const menuItems = [
    { path: "/admin/dashboard", label: "Dashboard", icon: "📊" },
    { path: "/admin/users", label: "Users", icon: "👥" },
    { path: "/admin/contacts", label: "Contact Messages", icon: "📧" },
    { path: "/admin/places", label: "Places", icon: "📍" },
  ];

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <>
      <button
        className="md:hidden p-3 text-white bg-gradient-to-r from-purple-400 to-purple-300 fixed top-4 left-4 z-50 rounded-lg shadow-lg"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? "❌" : "☰"}
      </button>

      {isOpen && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm md:hidden z-30"
          onClick={() => setIsOpen(false)}
        />
      )}

      <div
        className={`
          bg-gradient-to-b from-purple-900 to-purple-800 text-white shadow-xl 
          flex flex-col w-64 min-h-screen 

          /* Mobile slide effect */
          fixed top-0 left-0 transform transition-transform duration-300 z-40
          ${isOpen ? "translate-x-0" : "-translate-x-full"} 

          /* Desktop always visible */
          md:translate-x-0 md:static
        `}
      >
        {/* Logo */}
        <div className="p-6 border-b border-purple-700">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-purple-300 rounded-full flex items-center justify-center">
              <span className="text-xl">👑</span>
            </div>
            <div>
              <h1 className="text-xl font-bold">Admin Panel</h1>
              <p className="text-sm text-purple-300">
                TasteLens Control Center
              </p>
            </div>
          </div>
        </div>

        {/* Menu */}
        <nav className="p-4 flex-1">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all
                    ${
                      location.pathname === item.path
                        ? "bg-gradient-to-r from-purple-600 to-purple-500 shadow-lg"
                        : "hover:bg-purple-700/50"
                    }`}
                >
                  <span className="text-lg">{item.icon}</span>
                  <span className="font-medium">{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-purple-700">
          <button
            onClick={handleLogout}
            className="flex items-center justify-center space-x-2 w-full bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white py-3 rounded-lg transition-all shadow-md hover:shadow-lg"
          >
            <span>🚪</span>
            <span>Log Out</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default SideBar;
