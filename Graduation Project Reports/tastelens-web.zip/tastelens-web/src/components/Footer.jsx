import React from "react";
import { FaFacebookF, FaInstagram, FaTwitter, FaHeart } from "react-icons/fa";
import { SiTiktok } from "react-icons/si";
import logo from "../assets/logo.png";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white shadow-sm border-t border-gray-200 py-8 px-4">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center space-x-3 mb-6 md:mb-0 group">
            {logo ? (
              <img
                src={logo}
                alt="TasteLens Logo"
                className="w-16 h-16 object-contain transition-transform group-hover:scale-110"
              />
            ) : (
              <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">TL</span>
              </div>
            )}
            <div className="flex flex-col">
              <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                TasteLens
              </span>
              <span className="text-sm text-gray-400 font-medium">
                Culinary Journeys
              </span>
            </div>
          </div>

          <div className="flex space-x-4">
            <a
              href="#"
              className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-blue-50 hover:text-blue-600 transition-colors group"
              aria-label="Facebook"
            >
              <FaFacebookF className="w-4 h-4 text-gray-600 group-hover:scale-110 transition-transform" />
            </a>
            <a
              href="#"
              className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-purple-50 hover:text-purple-600 transition-colors group"
              aria-label="Instagram"
            >
              <FaInstagram className="w-4 h-4 text-gray-600 group-hover:scale-110 transition-transform" />
            </a>
            <a
              href="#"
              className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-blue-50 hover:text-blue-400 transition-colors group"
              aria-label="Twitter"
            >
              <FaTwitter className="w-4 h-4 text-gray-600 group-hover:scale-110 transition-transform" />
            </a>
            <a
              href="#"
              className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-black hover:text-white transition-colors group"
              aria-label="TikTok"
            >
              <SiTiktok className="w-4 h-4 text-gray-600 group-hover:scale-110 transition-transform" />
            </a>
          </div>
        </div>

        <div className="text-center  border-gray-200 pt-2">
          <p className="text-gray-600 text-sm">
            © {currentYear} TasteLens. All rights reserved. | Discover flavors
            that match your mood.
          </p>
          <p className="text-gray-500 text-sm mt-2 flex items-center justify-center">
            Designed with <FaHeart className="w-3 h-3 text-red-500 mx-1" /> for
            food lovers everywhere
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
