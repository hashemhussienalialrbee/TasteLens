import React, { useState } from "react";

const PasswordInput = ({ label, name, value, onChange, placeholder }) => {
  const [show, setShow] = useState(false);

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        {label}
      </label>

      <div className="relative">
        <input
          type={show ? "text" : "password"}
          name={name}
          value={value}
          placeholder={placeholder}
          onChange={onChange}
          required
          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg 
          focus:outline-none focus:border-purple-400 transition-colors"
        />

        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute right-3 top-3 text-gray-500"
        >
          {show ? "🙈" : "👁️"}
        </button>
      </div>
    </div>
  );
};

export default PasswordInput;
