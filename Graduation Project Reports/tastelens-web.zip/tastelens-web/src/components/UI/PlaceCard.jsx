import React from "react";

const PlaceCard = ({ place, onClick }) => (
  <div
    onClick={() => onClick(place)}
    className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 cursor-pointer"
  >
    <div className="h-48 overflow-hidden">
      <img
        src={place.image}
        alt={place.name}
        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
      />
    </div>
    <div className="p-4">
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-bold text-lg text-gray-900">{place.name}</h3>
        <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-semibold">
          {place.governorate}
        </span>
      </div>
      <p className="text-gray-600 text-sm mb-3 line-clamp-2">
        {place.description}
      </p>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center">
          <span className="text-amber-500 font-bold">★ {place.rating}</span>
          <span className="mx-2 text-gray-300">•</span>
          <span className="text-gray-600">{place.price}</span>
        </div>
        <span className="text-xs text-gray-500">{place.location}</span>
      </div>
      <div className="flex flex-wrap gap-1">
        {place.tags.slice(0, 3).map((tag, index) => (
          <span
            key={index}
            className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs"
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  </div>
);

export default PlaceCard;
