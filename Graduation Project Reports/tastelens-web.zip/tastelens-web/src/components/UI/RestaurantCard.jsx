import React from "react";

const RestaurantCard = ({ name, type, rating, imageColor, imageUrl }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow hover:-translate-y-1 duration-300">
      <div className="relative h-48">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className={`w-full h-full ${imageColor}`}></div>
        )}

        <div className="absolute top-4 right-4">
          <span className="bg-gradient-to-r from-orange-400 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-medium">
            {rating} ★
          </span>
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-bold text-gray-900">{name}</h3>
        </div>
        <p className="text-gray-600 mb-4">{type}</p>
      </div>
    </div>
  );
};

export default RestaurantCard;
