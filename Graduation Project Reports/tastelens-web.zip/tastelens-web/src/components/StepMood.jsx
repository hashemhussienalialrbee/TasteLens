import React from "react";
import { FaMagic, FaCheckCircle, FaLightbulb } from "react-icons/fa";
import moods from "../data/moods";
import { HOW_IT_WORKS } from "../data/constants";

const StepMood = ({ selectedMood, onSelect }) => (
  <div className="text-center">
    <div className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-4 rounded-full mb-8 shadow-lg shadow-purple-200 animate-pulse">
      <FaMagic className="text-xl" />
      <span className="font-bold text-lg tracking-wide">
        Step 1: How are you feeling today?
      </span>
    </div>

    <h2 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-600 mb-4">
      Choose Your Vibe
    </h2>
    <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed">
      Tell us how you feel and our AI will curate perfect places just for you
    </p>

    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
      {moods.map((mood) => (
        <button
          key={mood.id}
          onClick={() => onSelect(mood)}
          className={`
            flex flex-col items-center justify-center p-8 rounded-3xl 
            transition-all duration-500 transform hover:scale-105 hover:-translate-y-2
            relative overflow-hidden group
            ${mood.color}
            ${
              selectedMood?.id === mood.id
                ? "ring-4 ring-white ring-opacity-30 scale-105 shadow-2xl"
                : "shadow-xl hover:shadow-2xl"
            }
          `}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-white/0 to-white/10 group-hover:from-white/10 group-hover:to-white/20 transition-all duration-500"></div>

          <span className="text-5xl mb-6 transform group-hover:scale-110 transition-transform duration-300">
            {mood.icon}
          </span>
          <span className="font-bold text-gray-900 text-xl relative z-10">
            {mood.name}
          </span>
          {selectedMood?.id === mood.id && (
            <div className="absolute top-4 right-4">
              <FaCheckCircle className="text-white text-lg" />
            </div>
          )}
        </button>
      ))}
    </div>

    <div className="mt-16 bg-gradient-to-br from-white to-purple-50 rounded-3xl p-10 max-w-4xl mx-auto shadow-xl border border-purple-100">
      <div className="flex items-center justify-center mb-8">
        <div className="p-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl mr-4 shadow-lg">
          <FaLightbulb className="text-2xl text-white" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900">
          How AI Explorer Works
        </h3>
      </div>
      <div className="grid md:grid-cols-3 gap-8 text-left">
        {HOW_IT_WORKS.map((item, idx) => (
          <div
            key={idx}
            className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300"
          >
            <div className="text-4xl mb-4">{item.icon}</div>
            <h4 className="font-bold text-lg mb-2 text-gray-800">
              {item.title}
            </h4>
            <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </div>
);

export default StepMood;
