import React from "react";
import {
  FaStar,
  FaMapMarkerAlt,
  FaMoneyBillWave,
  FaArrowRight,
  FaRobot,
} from "react-icons/fa";
import { getRandomImage } from "../utils/helpers";

const RecommendationCard = ({ place, selectedMood, onClick, index }) => (
  <div
    className="bg-white rounded-3xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500 transform hover:-translate-y-2 cursor-pointer group"
    style={{ animationDelay: `${index * 100}ms` }}
    onClick={onClick}
  >
    <div className="h-56 overflow-hidden relative">
      <img
        src={place.image || getRandomImage()}
        alt={place.name}
        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
      <div className="absolute top-4 left-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
        <FaStar className="inline mr-2" /> AI PICK
      </div>
      <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-xs font-bold">
        {place.type?.toUpperCase() || "PLACE"}
      </div>
    </div>

    <div className="p-7">
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="text-xs font-bold text-purple-600 uppercase tracking-wider mb-1">
            AI Recommendation #{index + 1}
          </div>
          <h3 className="text-2xl font-bold text-gray-900 group-hover:text-purple-600 transition-colors">
            {place.name}
          </h3>
        </div>
        <div className="text-4xl transform group-hover:scale-110 transition-transform">
          {selectedMood?.icon}
        </div>
      </div>

      <p className="text-gray-600 mb-6 line-clamp-2 leading-relaxed">
        {place.description}
      </p>

      <div className="flex items-center text-gray-500 mb-6">
        <FaMapMarkerAlt className="mr-3 text-purple-500" />
        <span className="font-medium">{place.location}</span>
      </div>

      <div
        className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-bold mb-6 ${
          place.budget === "low"
            ? "bg-emerald-100 text-emerald-700"
            : place.budget === "medium"
            ? "bg-amber-100 text-amber-700"
            : "bg-rose-100 text-rose-700"
        }`}
      >
        <FaMoneyBillWave className="mr-2" />
        {place.budget?.toUpperCase() || "MEDIUM"} BUDGET
      </div>

      <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-5 rounded-2xl border border-purple-100 mb-6">
        <div className="flex items-start">
          <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl mr-4">
            <FaRobot className="text-white text-lg" />
          </div>
          <div>
            <div className="text-xs font-bold text-purple-700 uppercase tracking-wider mb-2">
              Why This Place?
            </div>
            <p className="text-purple-800 text-sm leading-relaxed">
              {place.reason}
            </p>
          </div>
        </div>
      </div>

      <button className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-2xl font-bold hover:from-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl group-hover:shadow-2xl flex items-center justify-center gap-3">
        <span>View Details</span>
        <FaArrowRight className="group-hover:translate-x-1 transition-transform" />
      </button>
    </div>
  </div>
);

export default RecommendationCard;
