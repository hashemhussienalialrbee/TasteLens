import { dummyImages } from "../data/constants";

export const getRandomImage = () =>
  dummyImages[Math.floor(Math.random() * dummyImages.length)];

export const getFallbackRecommendations = (city) => [
  {
    id: 1,
    name: "Cafe Strada",
    description:
      "Cozy cafe with great coffee and relaxing atmosphere perfect for unwinding after a long day",
    type: "cafe",
    budget: "medium",
    location: `${city}, Jordan`,
    reason:
      "Perfect for your mood with comfortable seating, ambient music, and great coffee selection",
    image: getRandomImage(),
  },
  {
    id: 2,
    name: "Wild Jordan Center",
    description:
      "Nature center with breathtaking views, local crafts, and sustainable tourism experiences",
    type: "nature",
    budget: "low",
    location: `${city}, Jordan`,
    reason:
      "Matches your preference for peaceful environments and connection with nature",
    image: getRandomImage(),
  },
  {
    id: 3,
    name: "Abdali Mall",
    description:
      "Modern shopping destination with premium brands, dining options, and entertainment facilities",
    type: "shopping",
    budget: "high",
    location: `${city}, Jordan`,
    reason:
      "Great for socializing, entertainment, and premium shopping experience",
    image: getRandomImage(),
  },
];

export const validateUserDetails = (details) => {
  if (!details.age || details.age < 1 || details.age > 120) {
    return "Please enter a valid age between 1 and 120";
  }
  if (!details.city || details.city.trim() === "") {
    return "Please enter a city";
  }
  return null;
};
