import axios from "axios";
import Cookies from "js-cookie";
import { toast } from "react-toastify";

const API_URL = "http://localhost:7400";

const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
    "x-api-key": "VFJFVklBUElLRVlAMjAyMw666==",
  },
});

api.interceptors.request.use(
  (config) => {
    const token = Cookies.get("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      Cookies.remove("token");
      window.location.href = "/login";
    }

    const errorMessage =
      error.response?.data?.message || error.message || "Something went wrong";
    toast.error(errorMessage, { autoClose: 3000 });

    return Promise.reject(error);
  }
);

export { api };
