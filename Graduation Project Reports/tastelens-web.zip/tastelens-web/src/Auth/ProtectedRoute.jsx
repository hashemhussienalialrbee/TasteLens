import { Navigate } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "./authProvider";

const ProtectedRoute = ({ children, allowedTypes = ["user", "admin"] }) => {
  const { isAuthenticated, accountType, loading } = useContext(AuthContext);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedTypes.includes(accountType)) {
    switch (accountType) {
      case "admin":
        return <Navigate to="/admin/dashboard" replace />;
      case "user":
        return <Navigate to="/home" replace />;
      default:
        return <Navigate to="/login" replace />;
    }
  }

  return children;
};

export default ProtectedRoute;
