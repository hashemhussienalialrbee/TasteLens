import { createContext, useEffect, useState } from "react";
import Cookies from "js-cookie";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [accountType, setAccountType] = useState(null);
  const [loading, setLoading] = useState(true);
  const [first_name, setFirstName] = useState("");

  const login = (userData, token, account_type) => {
    const { password, ...userWithoutPassword } = userData;
    setUser(userWithoutPassword);
    setFirstName(userData.first_name);
    setToken(token);
    setAccountType(account_type);

    Cookies.set("token", token, { expires: 7 });
    Cookies.set("account_type", account_type, { expires: 7 });
    Cookies.set("user_name", userData.first_name, { expires: 7 });
    Cookies.set(
      "user",
      encodeURIComponent(JSON.stringify(userWithoutPassword)),
      { expires: 7 }
    );
  };

  const logout = () => {
    setUser(null);
    setFirstName("");
    setToken(null);
    setAccountType(null);

    Cookies.remove("token");
    Cookies.remove("account_type");
    Cookies.remove("user");
    Cookies.remove("user_name");

    window.location.href = "/login";
  };

  useEffect(() => {
    const checkAuth = () => {
      try {
        const storedToken = Cookies.get("token");
        const storedAccountType = Cookies.get("account_type");
        const storedUser = Cookies.get("user");

        if (storedToken && storedAccountType && storedUser) {
          setToken(storedToken);
          setAccountType(storedAccountType);

          try {
            const parsedUser = JSON.parse(storedUser);
            setUser(parsedUser);
            setFirstName(parsedUser.first_name || "");
          } catch {
            const decodedUser = decodeURIComponent(storedUser);
            const parsedUser = JSON.parse(decodedUser);
            setUser(parsedUser);
            setFirstName(parsedUser.first_name || "");
          }
        }
      } catch (error) {
        console.error("Auth error:", error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const updateUser = (updatedUserData) => {
    const { password, ...userWithoutPassword } = updatedUserData;

    setUser(userWithoutPassword);
    setFirstName(userWithoutPassword.first_name || "");

    Cookies.set(
      "user",
      encodeURIComponent(JSON.stringify(userWithoutPassword)),
      { expires: 7 }
    );

    if (userWithoutPassword.first_name) {
      Cookies.set("user_name", userWithoutPassword.first_name, { expires: 7 });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        accountType,
        first_name,
        login,
        logout,
        updateUser,
        loading,
        isAuthenticated: !!token && !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
