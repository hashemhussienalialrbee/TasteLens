import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { AuthProvider } from "./Auth/authProvider";
import ProtectedRoute from "./Auth/ProtectedRoute";
import Landing from "./Screens/Landing";
import NotFound from "./Screens/NotFound";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Login from "./Screens/auth/SignIn";
import Signup from "./Screens/auth/SignUp";
import ForgotPassword from "./Screens/auth/ForgotPassword";
import ResetPassword from "./Screens/auth/ResetPassword";
import VerifyOTP from "./Screens/auth/VerifyOTP";
import Home from "./Screens/Home";
import About from "./Screens/AboutUs";
import Contact from "./Screens/ContactUs";
import Dashboard from "./Screens/Admin/Dashboard";
import AdminUsers from "./Screens/Admin/Users";
import ContactMessages from "./Screens/Admin/ContactMessages";
import AdminLayout from "./components/AdminLayout";
import UserProfile from "./Screens/auth/UserProfile";
import Activities from "./Screens/Activities";
import ActivityDetail from "./Screens/ActivityDetail";
import AIRecommendedPlace from "./Screens/AIRecommendedPlace";
import AdminPlaces from "./Screens/Admin/Places";
import UserPlaces from "./Screens/Places";
import PlaceDetails from "./Screens/PlacesDetails";
import PlaceAdd from "./Screens/PlaceAdd";

function App() {
  return (
    <AuthProvider>
      <Router>
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
        />

        <Routes>
          {/* Public Routes with Header & Footer */}
          <Route
            path="/*"
            element={
              <div className="min-h-screen flex flex-col">
                <Header />
                <main className="flex-grow">
                  <Routes>
                    <Route path="/" element={<Landing />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/signup" element={<Signup />} />
                    <Route
                      path="/forgot-password"
                      element={<ForgotPassword />}
                    />
                    <Route
                      path="/place/ai-recommended"
                      element={<AIRecommendedPlace />}
                    />
                    <Route path="/verify-otp" element={<VerifyOTP />} />
                    <Route path="/reset-password" element={<ResetPassword />} />
                    UserProfile
                    <Route path="/user-profile" element={<UserProfile />} />
                    <Route path="/about-us" element={<About />} />
                    <Route path="/contact-us" element={<Contact />} />
                    <Route path="/activities" element={<Activities />} />
                    <Route
                      path="/activities/:id"
                      element={<ActivityDetail />}
                    />
                    <Route path="/places" element={<UserPlaces />} />
                    <Route path="/places/:id" element={<PlaceDetails />} />
                    <Route path="/place-add" element={<PlaceAdd />} />
                    {/* Regular User Routes */}
                    <Route
                      path="/home"
                      element={
                        <ProtectedRoute allowedTypes={["user"]}>
                          <Home />
                        </ProtectedRoute>
                      }
                    />
                    {/* 404 */}
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </main>
                <Footer />
              </div>
            }
          />

          {/* Admin Routes */}
          <Route
            path="/admin/*"
            element={
              <ProtectedRoute allowedTypes={["admin"]}>
                <AdminLayout />
              </ProtectedRoute>
            }
          >
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="contacts" element={<ContactMessages />} />
            <Route path="places" element={<AdminPlaces />} />
            {/* 404 */}
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
